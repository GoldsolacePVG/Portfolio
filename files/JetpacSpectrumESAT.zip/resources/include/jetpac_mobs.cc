void InitMobs(){
    mobs = (TEnemies*)calloc(6, sizeof(TEnemies));

    for(int i = 0; i < 6; i++){
        (mobs + i)->index = 1;
        (mobs + i)->sprite = (g_fireball_enemy + 0);
        (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};
        (mobs + i)->speed = 4;
        (mobs + i)->is_alive = false;
        (mobs + i)->is_ready = true;
        (mobs + i)->score = 25;
        (mobs + i)->anim_count = 0;
        // (mobs + i)->is_active = false;
        (mobs + i)->ovni_count = 0;
    }
}

void UpdateMobs(){
    if(player.level != 4){
        for(int i = 0; i < 5; i++){
            (mobs + i)->index = player.level;
            if((mobs + i)->index != 5){
                (mobs + i)->spawn = rand()%2;
            }
            if((mobs + i)->index == 5 || (mobs + i)->index == 8){
                (mobs + i)->spawn = rand()%10;
            }
            (mobs + i)->spawn2 = rand()%2;
            (mobs + i)->aux = (rand()%670) + 53;
            if(!(mobs + i)->is_alive && (mobs + i)->is_ready && (mobs + i)->spawn == 1){
                SetEnemy(i);
            }
            if((mobs + i)->is_alive && !(mobs + i)->is_ready){
                if((mobs + i)->position.x > kWindowWidth + 50){
                    (mobs + i)->position.x = 1 - 50;  
                }
                if((mobs + i)->position.x <= 0 - 50){
                    (mobs + i)->position.x = kWindowWidth + 50;
                }

                //FULFF
                if((mobs + i)->index == 2){
                    (mobs + i)->anim_count++;
                    //RED
                    if((mobs + i)->color == 0){
                        if((mobs + i)->anim_count < 5){
                            (mobs + i)->sprite = (g_fluff_enemy + 0);
                        }
                        if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                            (mobs + i)->sprite = (g_fluff_enemy + 1);
                        }
                        if((mobs + i)->anim_count == 10){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    //GREEN
                    if((mobs + i)->color == 1){
                        if((mobs + i)->anim_count < 5){
                            (mobs + i)->sprite = (g_fluff_enemy + 2);
                        }
                        if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                            (mobs + i)->sprite = (g_fluff_enemy + 3);
                        }
                        if((mobs + i)->anim_count == 10){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    //BLUE
                    if((mobs + i)->color == 2){
                        if((mobs + i)->anim_count < 5){
                            (mobs + i)->sprite = (g_fluff_enemy + 4);
                        }
                        if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                            (mobs + i)->sprite = (g_fluff_enemy + 5);
                        }
                        if((mobs + i)->anim_count == 10){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    //PINK
                    if((mobs + i)->color == 3){
                        if((mobs + i)->anim_count < 5){
                            (mobs + i)->sprite = (g_fluff_enemy + 6);
                        }
                        if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                            (mobs + i)->sprite = (g_fluff_enemy + 7);
                        }
                        if((mobs + i)->anim_count == 10){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};
                }

                //BUBBLE
                if((mobs + i)->index == 3){
                    (mobs + i)->anim_count++;
                    //RED
                    if((mobs + i)->color == 0){
                        if((mobs + i)->anim_count < 15){
                            (mobs + i)->sprite = (g_bubble_enemy + 0);
                        }
                        if((mobs + i)->anim_count >= 15 && (mobs + i)->anim_count < 25){
                            (mobs + i)->sprite = (g_bubble_enemy + 1);
                        }
                        if((mobs + i)->anim_count == 25){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    //GREEN
                    if((mobs + i)->color == 1){
                        if((mobs + i)->anim_count < 15){
                            (mobs + i)->sprite = (g_bubble_enemy + 2);
                        }
                        if((mobs + i)->anim_count >= 15 && (mobs + i)->anim_count < 25){
                            (mobs + i)->sprite = (g_bubble_enemy + 3);
                        }
                        if((mobs + i)->anim_count == 25){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    //BLUE
                    if((mobs + i)->color == 2){
                        if((mobs + i)->anim_count < 15){
                            (mobs + i)->sprite = (g_bubble_enemy + 4);
                        }
                        if((mobs + i)->anim_count >= 15 && (mobs + i)->anim_count < 25){
                            (mobs + i)->sprite = (g_bubble_enemy + 5);
                        }
                        if((mobs + i)->anim_count == 25){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    //PINK
                    if((mobs + i)->color == 3){
                        if((mobs + i)->anim_count < 15){
                            (mobs + i)->sprite = (g_bubble_enemy + 6);
                        }
                        if((mobs + i)->anim_count >= 15 && (mobs + i)->anim_count < 25){
                            (mobs + i)->sprite = (g_bubble_enemy + 7);
                        }
                        if((mobs + i)->anim_count == 25){
                            (mobs + i)->anim_count = 0;
                        }
                    }
                    (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};
                }

                //OVNI
                if((mobs + i)->index == 5 || (mobs + i)->index == 8){
                    (mobs + 5)->position.x = 1500;
                    (mobs + 5)->position.y = 2000;
                    if((mobs + i)->index == 5){
                        //RED
                        if((mobs + i)->color == 0){(mobs + i)->sprite = (g_ovni_enemy + 0);}
                        //GREEN
                        if((mobs + i)->color == 1){(mobs + i)->sprite = (g_ovni_enemy + 1);}
                        //BLUE
                        if((mobs + i)->color == 2){(mobs + i)->sprite = (g_ovni_enemy + 2);}
                        //PINK
                        if((mobs + i)->color == 3){(mobs + i)->sprite = (g_ovni_enemy + 3);}
                    }
                    (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};
                    if((mobs + i)->index == 8){
                        //RED
                        if((mobs + i)->color == 0){(mobs + i)->sprite = (g_glass_enemy + 0);}
                        //GREEN
                        if((mobs + i)->color == 1){(mobs + i)->sprite = (g_glass_enemy + 1);}
                        //BLUE
                        if((mobs + i)->color == 2){(mobs + i)->sprite = (g_glass_enemy + 2);}
                        //PINK
                        if((mobs + i)->color == 3){(mobs + i)->sprite = (g_glass_enemy + 3);}
                    }
                    (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};

                    if((mobs + i)->is_alive && !(mobs + i)->is_ready){
                        if((mobs + i)->position.x < player.position.x && !OvniCollision(i)){
                            (mobs + i)->direction = 1;
                        }
                        if((mobs + i)->position.x > player.position.x && !OvniCollision(i)){
                            (mobs + i)->direction = 3;
                        }
                        if((mobs + i)->position.y > player.position.y && !OvniCollision(i)){
                            (mobs + i)->direction2 = 0;
                        }
                        if((mobs + i)->position.y < player.position.y && !OvniCollision(i)){
                            (mobs + i)->direction2 = 1;
                        }
                        if(OvniCollision(i)){
                            (mobs + i)->ovni_col = true;
                        }
                        if((mobs + i)->ovni_col){
                            // (mobs + i)->ovni_count = 0;
                            (mobs + i)->ovni_count++;
                            if((mobs + i)->ovni_count <= 20){
                                switch((mobs + i)->direction2){
                                    case 0:
                                        (mobs + i)->direction2 = 1;
                                    break;
                                    case 1:
                                        (mobs + i)->direction2 = 0;
                                    break;
                                }
                            }else if((mobs + i)->ovni_count > 20){
                                switch((mobs + i)->direction2){
                                    case 0:
                                        (mobs + i)->direction2 = 1;
                                    break;
                                    case 1:
                                        (mobs + i)->direction2 = 0;
                                    break;
                                }
                                (mobs + i)->ovni_col = false;
                                (mobs + i)->ovni_count = 0;
                            }
                        }
                    }
                }

                //CROSS
                if((mobs + i)->index == 6){
                    switch((mobs + i)->color){
                        case 0:
                            (mobs + i)->sprite = (g_cross_enemy + 0);
                        break;
                        case 1:
                            (mobs + i)->sprite = (g_cross_enemy + 1);
                        break;
                        case 2:
                            (mobs + i)->sprite = (g_cross_enemy + 2);
                        break;
                        case 3:
                            (mobs + i)->sprite = (g_cross_enemy + 3);
                        break;
                    }
                    (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};
                }

                //FALCON
                if((mobs + i)->index == 7){
                    switch((mobs + i)->color){                        
                        case 0:
                            if((mobs + i)->direction == 1){(mobs + i)->sprite = (g_falcon_enemy + 0);}
                            if((mobs + i)->direction == 3){(mobs + i)->sprite = (g_falcon_enemy + 1);}
                        break;
                        case 1:
                            if((mobs + i)->direction == 1){(mobs + i)->sprite = (g_falcon_enemy + 2);}
                            if((mobs + i)->direction == 3){(mobs + i)->sprite = (g_falcon_enemy + 3);}
                        break;
                        case 2:
                            if((mobs + i)->direction == 1){(mobs + i)->sprite = (g_falcon_enemy + 4);}
                            if((mobs + i)->direction == 3){(mobs + i)->sprite = (g_falcon_enemy + 5);}
                        break;
                        case 3:
                            if((mobs + i)->direction == 1){(mobs + i)->sprite = (g_falcon_enemy + 6);}
                            if((mobs + i)->direction == 3){(mobs + i)->sprite = (g_falcon_enemy + 7);}
                        break;
                    }
                    (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};
                }

                if((mobs + i)->position.y <= 53){
                    if((mobs + i)->index == 1 || (mobs + i)->index == 7){
                        (mobs + i)->is_alive = false;
                        (mobs + i)->is_ready = true;
                    }
                    if((mobs + i)->index == 2 || (mobs + i)->index == 3 || (mobs + i)->index == 5 || (mobs + i)->index == 6 || (mobs + i)->index == 8){
                        switch((mobs + i)->direction2){
                            case 0:
                                (mobs + i)->direction2 = 1;
                            break;
                            case 1:
                                (mobs + i)->direction2 = 0;
                            break;
                        }
                    }
                }


                //FIREBALL
                switch((mobs + i)->direction){
                    case 1:
                        (mobs + i)->position.x += (mobs + i)->speed;
                        if((mobs + i)->index == 1){
                            (mobs + i)->anim_count++;
                            //RED
                            if((mobs + i)->color == 0){
                                (mobs + i)->sprite = (g_fireball_enemy + 0);
                                if((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 0);
                                }
                                if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 2);
                                }
                                if((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                            //GREEN
                            if((mobs + i)->color == 1){
                                (mobs + i)->sprite = (g_fireball_enemy + 4);
                                if((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 4);
                                }
                                if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 6);
                                }
                                if((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                            //BLUE
                            if((mobs + i)->color == 2){
                                (mobs + i)->sprite = (g_fireball_enemy + 8);
                                if((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 8);
                                }
                                if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 10);
                                }
                                if((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                            //PINK
                            if((mobs + i)->color == 3){
                                (mobs + i)->sprite = (g_fireball_enemy + 12);
                                if((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 12);
                                }
                                if((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 14);
                                }
                                if((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                        }
                    break;
                    case 3:
                        (mobs + i)->position.x -= (mobs + i)->speed;
                        if((mobs + i)->index == 1){
                            (mobs + i)->anim_count++;
                            // RED
                            if((mobs + i)->color == 0){
                                (mobs + i)->sprite = (g_fireball_enemy + 1);
                                if ((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 1);
                                }
                                if ((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 3);
                                }
                                if ((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                            // GREEN
                            if((mobs + i)->color == 1){
                                (mobs + i)->sprite = (g_fireball_enemy + 5);
                                if ((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 5);
                                }
                                if ((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 7);
                                }
                                if ((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                            // BLUE
                            if((mobs + i)->color == 2){
                                (mobs + i)->sprite = (g_fireball_enemy + 9);
                                if ((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 9);
                                }
                                if ((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 11);
                                }
                                if ((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                            // PINK
                            if((mobs + i)->color == 3){
                                (mobs + i)->sprite = (g_fireball_enemy + 13);
                                if ((mobs + i)->anim_count < 5){
                                    (mobs + i)->sprite = (g_fireball_enemy + 13);
                                }
                                if ((mobs + i)->anim_count >= 5 && (mobs + i)->anim_count < 10){
                                    (mobs + i)->sprite = (g_fireball_enemy + 15);
                                }
                                if ((mobs + i)->anim_count == 10){
                                    (mobs + i)->anim_count = 0;
                                }
                            }
                        }
                    break;
                }

                g_bubble_dir_rand = rand()%150;
                switch((mobs + i)->direction2){
                    case 0:
                        if((mobs + i)->index == 1 || (mobs + i)->index == 7){(mobs + i)->position.y -= (mobs + i)->movements;}
                        if((mobs + i)->index == 2){(mobs + i)->position.y -= 3;}
                        if((mobs + i)->index == 3){
                            (mobs + i)->position.y -= 3;
                            if(g_bubble_dir_rand >= 100){
                                (mobs + i)->position.y -= 0;
                            }
                        }
                        if((mobs + i)->index == 6){(mobs + i)->position.y -= 2;}
                        if((mobs + i)->index == 5 || (mobs + i)->index == 8){(mobs + i)->position.y -= (rand() % 2) + 1;}
                    break;
                    case 1:
                        if((mobs + i)->index == 1 || (mobs + i)->index == 7){(mobs + i)->position.y -= (mobs + i)->movements;}
                        if((mobs + i)->index == 2){(mobs + i)->position.y += 3;}
                        if((mobs + i)->index == 3){
                            (mobs + i)->position.y += 3;
                            if(g_bubble_dir_rand >= 100){
                                (mobs + i)->position.y += 0;
                            }
                        }
                        if((mobs + i)->index == 6){(mobs + i)->position.y += 2;}
                        if((mobs + i)->index == 5 || (mobs + i)->index == 8){(mobs + i)->position.y += (rand() % 2) + 1;}
                    break;
                }
                EnemyToPlatformColision(i);
            }
        }
    }else{
        for(int i = 0; i < 6; i++){
            (mobs + i)->index = player.level;
            (mobs + i)->spawn = rand() % 2;
            (mobs + i)->spawn2 = rand() % 2;
            (mobs + i)->aux = (rand() % 670) + 53;
            if(!(mobs + i)->is_alive && (mobs + i)->is_ready && (mobs + i)->spawn == 1){
                SetEnemy(i);
            }
            if((mobs + i)->is_alive && !(mobs + i)->is_ready && !(mobs + i)->is_active){
                if((mobs + i)->direction2 == 0){
                    (mobs + i)->position.y -= 3;
                }
                if((mobs + i)->direction2 == 1){
                    (mobs + i)->position.y += 3;
                }
                if((mobs + i)->position.y <= 0){
                    (mobs + i)->direction2 = 1;
                }
                if((mobs + i)->position.y >= kWindowHeight - 50){
                    (mobs + i)->direction2 = 0;
                }
                if((mobs + i)->position.y >= player.position.y && (mobs + i)->position.y <= player.position.y + player.size.y){
                    (mobs + i)->is_active = true;
                }
                if((mobs + i)->direction == 1){
                    switch((mobs + i)->color){
                    // RED
                    case 0:
                        (mobs + i)->sprite = (g_plane_enemy + 0);
                    break;
                    // GREEN
                    case 1:
                        (mobs + i)->sprite = (g_plane_enemy + 2);
                    break;
                    // BLUE
                    case 2:
                        (mobs + i)->sprite = (g_plane_enemy + 4);
                    break;
                    // PINK
                    case 3:
                        (mobs + i)->sprite = (g_plane_enemy + 6);
                    break;
                    }
                }
                if((mobs + i)->direction == 3){
                    switch((mobs + i)->color){
                    // RED
                    case 0:
                        (mobs + i)->sprite = (g_plane_enemy + 1);
                    break;
                    // GREEN
                    case 1:
                        (mobs + i)->sprite = (g_plane_enemy + 3);
                    break;
                    // BLUE
                    case 2:
                        (mobs + i)->sprite = (g_plane_enemy + 5);
                    break;
                    // PINK
                    case 3:
                        (mobs + i)->sprite = (g_plane_enemy + 7);
                    break;
                    }
                }
            }
            if((mobs + i)->is_alive && !(mobs + i)->is_ready && (mobs + i)->is_active){
                switch((mobs + i)->direction){
                    case 1:
                        (mobs + i)->sprite = (g_plane_enemy + 8);
                        (mobs + i)->position.x += (mobs + i)->speed;
                    break;
                    case 3:
                        (mobs + i)->sprite = (g_plane_enemy + 9);
                        (mobs + i)->position.x -= (mobs + i)->speed;
                    break;
                }
                (mobs + i)->size = {(float)esat::SpriteWidth(*(mobs + i)->sprite), (float)esat::SpriteHeight(*(mobs + i)->sprite)};
                switch((mobs + i)->direction){
                    case 1:
                        if((mobs + i)->position.x <= player.position.x){
                            if((mobs + i)->position.y > player.position.y){
                                (mobs + i)->direction2 = 0;
                            }
                            if((mobs + i)->position.y < player.position.y){
                                (mobs + i)->direction2 = 1;
                            }
                        }
                    break;
                    case 3:
                        if((mobs + i)->position.x >= player.position.x){
                            if((mobs + i)->position.y > player.position.y){
                                (mobs + i)->direction2 = 0;
                            }
                            if((mobs + i)->position.y < player.position.y){
                                (mobs + i)->direction2 = 1;
                            }
                        }
                    break;
                }

                if((mobs + i)->position.x > kWindowWidth + 50){
                    (mobs + i)->position.x = 1 - 50;
                }
                if((mobs + i)->position.x <= 0 - 50){
                    (mobs + i)->position.x = kWindowWidth + 50;
                }
                if((mobs + i)->position.y <= 53){
                    (mobs + i)->is_alive = false;
                    (mobs + i)->is_ready = true;
                }
                switch((mobs + i)->direction2){
                    case 0:
                        (mobs + i)->position.y -= 2;
                    break;
                    case 1:
                        (mobs + i)->position.y += 2;
                    break;
                }
                EnemyToPlatformColision(i);
            }
        }
    }
}

void DrawMobs(){
    if(player.level != 4){
        for(int i = 0; i < 5; i++){
            if((mobs + i)->is_alive && !(mobs + i)->is_ready){
                esat::DrawSprite(*(mobs + i)->sprite, (mobs + i)->position.x, (mobs + i)->position.y);
            }
        }
    }else{
        for(int i = 0; i < 6; i++){
            if((mobs + i)->is_alive && !(mobs + i)->is_ready){
                esat::DrawSprite(*(mobs + i)->sprite, (mobs + i)->position.x, (mobs + i)->position.y);
            }
        }
    }
}