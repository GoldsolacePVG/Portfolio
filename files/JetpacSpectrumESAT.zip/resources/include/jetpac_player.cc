void InitPlayerAndBullet(TPlayer *player){
    bullet = (TBullet*)calloc(4, sizeof(TBullet));
    //Player
    (*player).position.x = kWindowWidth/2;
    (*player).position.y = kWindowHeight - 110;
    (*player).lives = 3;
    (*player).gravity = true;
    (*player).speed = 12;
    (*player).direction = 3;
    (*player).dir = 3;
    (*player).size = {(float)esat::SpriteWidth(*(g_player + 0)), (float)esat::SpriteHeight(*(g_player + 0))};
    (*player).score = 0;
    (*player).score2 = 0;
    (*player).death_counter = 0;
    (*player).immortality = 0;
    (*player).level = 1;
    (*player).ship_level = 1;
    (*player).move.up = true;
    (*player).move.down = true;
    (*player).move.right = true;
    (*player).move.left = true;
    (*player).is_alive = true;
    (*player).grip = false;
    //Bullet
    for(int i = 0; i < 4; i++){
        (bullet + i)->size.x = 50;
        (bullet + i)->size.y = 3;
        (bullet + i)->speed = 30;
        (bullet + i)->is_active = false;
        (bullet + i)->is_ready = true;
    }
}

void UpdatePlayerAndBullet(TPlayer *player){
    //PLAYER
    if((*player).is_alive){
        if((*player).gravity && (*player).move.down){
            (*player).position.y += kGravity;
        }
        //INPUTS
        if(esat::IsSpecialKeyPressed(esat::kSpecialKey_Right) && (*player).move.right){
            (*player).position.x += (*player).speed;
            (*player).direction = 1;
            (*player).dir = 1;
        }
        if(esat::IsSpecialKeyPressed(esat::kSpecialKey_Left) && (*player).move.left){
            (*player).position.x -= (*player).speed;
            (*player).direction = 3;
            (*player).dir = 3;
        }
        if(esat::IsSpecialKeyPressed(esat::kSpecialKey_Up) && (*player).position.y >= 53 && (*player).move.up){
            // SetExplosionAnim((*player).position.x, (*player).position.y + 35);
            (*player).position.y -= (*player).speed;
            (*player).move.down = true;
        }
        if(esat::IsSpecialKeyDown(esat::kSpecialKey_Space) && (bullet + 3)->is_ready && !(bullet + 3)->is_active && bullet_counter <= 3){
            SetBullet(bullet_counter);
            soloud.play(shoot);
            bullet_counter++;
        }
        if(bullet_counter > 3){
            time_between_bullet++;
            if(time_between_bullet == 40){
                bullet_counter = 0;
                time_between_bullet = 0;
            }
        }

        //LIMITES
        if((*player).position.x > kWindowWidth + 50){
            (*player).position.x = 1 - 50;
        }
        if((*player).position.x <= 0 - 50){
            (*player).position.x = kWindowWidth + 50;
        }

        //COLLISIONS
        (*player).move.down = PlayerToPlatformDownCollision(player);
        (*player).move.up = PlayerToPlatformUpCollision(player);
        (*player).move.right = PlayerToPlatformRightCollision(player);
        (*player).move.left = PlayerToPlatformLeftCollision(player);
        PlayerToItemCollision(player);
        if(!g_immortal){
            g_player_dead = PlayerToMobsCollision(player);
        }

        //DIRECTION
        int aux;
        ++(*player).counter%=4;
        switch((*player).direction){
            case 1:
                if(!(*player).move.down){
                    (*player).sprite = *(g_player + 4 + (*player).counter);
                }
                if((*player).move.down){
                    (*player).sprite = *(g_player + 12 + (*player).counter);
                }
                aux = (*player).direction;
            break;
            case 3:
                if(!(*player).move.down){
                    (*player).sprite = *(g_player + 0 + (*player).counter);
                }
                if((*player).move.down){
                    (*player).sprite = *(g_player + 8 + (*player).counter);
                }
                aux = (*player).direction;
            break;
        }
        (*player).direction = 0;
    }
    //Player death
    if(g_player_dead){
        (*player).is_alive = false;
        for(int r = 1; r < 4; r++){
            (item + r)->taken = false;
        }
        if(!(*player).is_alive && g_player_dead){
            (*player).death_counter++;
            if((*player).death_counter == 60){
                for(int i = 0; i < 6; i++){
                    (mobs + i)->is_alive = false;
                    (mobs + i)->is_ready = true;
                }
                (*player).death_counter = 0;
                g_player_dead = false;
                (*player).is_alive = true;
                g_immortal = true;
            }
        }
    }
    if((*player).is_alive && g_immortal){
        (*player).immortality++;
        if((*player).immortality == 75){
            g_immortal = false;
            (*player).immortality = 0;
        }
    }

    //BULLET
    for(int k = 0; k < 4; k++){
        if((bullet + k)->is_active && !(bullet + k)->is_ready){
            (bullet + k)->counter++;
            switch((bullet + k)->dir){
                case 1:
                    (bullet + k)->position.x += (bullet + k)->speed;
                break;
                case 3:
                    (bullet + k)->position.x -= (bullet + k)->speed;
                break;
            }
            if((bullet + k)->size.x <= 200){
                (bullet + k)->size.x += 20;
            }
            if((bullet + k)->position.x >= kWindowWidth + 50){
                (bullet + k)->position.x = 1 - 50;
            }
            if((bullet + k)->position.x <= 0 - 50){
                (bullet + k)->position.x = kWindowWidth + 50;
            }

            if((bullet + k)->counter == 50){
                (bullet + k)->is_active = false;
                (bullet + k)->is_ready = true;
                (bullet + k)->counter = 0;
            }
            BulletToMobsCollision(k);
        }
    }

    if((*player).lives < 0){
        g_game_over = true;
    }
}

void DrawPlayer(TPlayer *player){
    //PLAYER
    if((*player).is_alive){
        esat::DrawSprite((*player).sprite, (*player).position.x, (*player).position.y);
    }
    if(g_immortal){
        esat::DrawSprite(g_shield, (*player).position.x - 25, (*player).position.y - 15);
    }
    //BULLET
    for(int i = 0; i < 4; i++){
        if((bullet + i)->is_active){
            TVec *points = nullptr;
            points = (TVec*)malloc(sizeof(TVec) * 4);
            *(points + 0) = {(bullet + i)->position.x, (bullet + i)->position.y};
            *(points + 1) = {(bullet + i)->position.x + (bullet + i)->size.x, (bullet + i)->position.y};
            *(points + 2) = {(bullet + i)->position.x + (bullet + i)->size.x, (bullet + i)->position.y + (bullet + i)->size.y};
            *(points + 3) = {(bullet + i)->position.x, (bullet + i)->position.y + (bullet + i)->size.y};
            if((bullet + i)->color == 0){esat::DrawSetFillColor(255, 255, 255);}
            if((bullet + i)->color == 1){esat::DrawSetFillColor(254, 3, 243);}
            if((bullet + i)->color == 2){esat::DrawSetFillColor(3, 201, 254);}
            esat::DrawSetStrokeColor(255, 255, 255, 0);
            esat::DrawSolidPath((float*)points, 4);
        }
    }
}