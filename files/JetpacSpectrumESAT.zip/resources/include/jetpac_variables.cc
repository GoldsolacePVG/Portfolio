//STRUCTS
struct TVec{
    float x, y;
};

struct TMove{
    bool up, down, right, left;
};

struct TBullet{
    TVec position, size;
    int speed, color, counter, dir;
    bool is_active, is_ready;
    esat::SpriteHandle sprite;
};

struct TMap{
    TVec position, size;
    esat::SpriteHandle *sprite;
};

struct TPlayer{
    TVec position, size;
    esat::SpriteHandle sprite;
    int lives, speed, direction, score, score2, counter;
    int death_counter, immortality, dir, level, ship_level;
    bool is_alive, gravity, grip;
    TMove move;
};

struct TItems1{
    TVec position, size;
    bool is_alive, is_ready, can_move, taken, has_arrived, falling, picked;
    int speed, score, type, count;
    esat::SpriteHandle *sprite;
    int aux, spawn;
};

struct TEnemies{
    TVec position, size;
    int index, direction, direction2, score, speed, color;
    bool is_alive, is_ready, is_active, ovni_col;
    esat::SpriteHandle *sprite;
    int aux, spawn, spawn2, movements, anim_count, ovni_count;
};

TPlayer player;
TBullet *bullet;
TMap *map;
TItems1 *item;
TEnemies *mobs;

//VARIABLES
//CONST
const unsigned int kWindowWidth = 990;
const unsigned int kWindowHeight = 800;
const int kGravity = 6;

//SPRITES
esat::SpriteHandle *g_player, g_small_plat, g_big_plat, g_ground_plat, g_1up, g_2up, g_hi, g_fuel,
                    g_live, g_ship1_1, g_ship1_2, g_ship1_3, g_ship2_1, g_ship2_2, g_ship2_3, g_ship3_1,
                    g_ship3_2, g_ship3_3, g_ship4_1, g_ship4_2, g_ship4_3, *g_nuclear, *g_triangle,
                    g_gold, g_pearl, g_author, *g_diamond, g_jet, g_jet_2, g_full_ship_1_1, g_full_ship_1_2,
                    g_full_ship_1_3, g_full_ship_1_4, g_full_ship_1_5, g_full_ship_1_6, g_full_ship_2_1, g_full_ship_2_2,
                    g_full_ship_2_3, g_full_ship_2_4, g_full_ship_2_5, g_full_ship_2_6, g_full_ship_3_1, g_full_ship_3_2,
                    g_full_ship_3_3, g_full_ship_3_4, g_full_ship_3_5, g_full_ship_3_6, g_full_ship_4_1, g_full_ship_4_2,
                    g_full_ship_4_3, g_full_ship_4_4, g_full_ship_4_5, g_full_ship_4_6, *g_selection_sprite,
                    *g_ship_explosion, *g_fireball_enemy, g_shield, *g_fluff_enemy, *g_bubble_enemy, *g_explosion_anim_1,
                    *g_explosion_anim_2, *g_explosion_anim_3, *g_plane_enemy, *g_ovni_enemy, *g_cross_enemy, *g_falcon_enemy,
                    *g_glass_enemy;
esat::SpriteHandle g_aux;

//INTEGERS
int g_img_counter = 0, g_menu_counter = 0, g_item_selector, g_item_counter = 0, g_fuel_counter = 0, g_full_counter = 0,
    g_ship_explosion_counter = 0, g_highscore = 0, g_bubble_dir_rand;
int simple_counter1 = 0, simple_counter2 = 0, bullet_counter = 0, time_between_bullet = 0, g_select_1_count = 0, g_select_2_count = 0,
    g_input_count = 1, g_explosion_count = 0;

//BOOLEANS
bool g_ship_complete = false, g_ship_full = false, g_fuel_t = false, g_diamond_t = false, g_pearl_t = false, 
     g_gold_t = false, g_nuclear_t = false, g_triangle_t = false, g_shipfull_alive_1 = false, g_shipfull_alive_2 = false, 
     g_shipfull_alive_3 = false, g_shipfull_alive_4 = false, g_shipfull_alive_5 = false, g_shipfull_alive_6 = false, 
     g_menu1 = true, g_menu2 = true, g_ship_exp_alive = false, g_player_dead = false, g_game_over = false, g_immortal = false,
     g_landing = false;
bool g_select_1 = true, g_select_2 = false, g_select_3 = false, g_explosion_alive = false, g_aux_land_bool = false;
bool g_audio_dep = true, g_audio_land = true;
bool g_player_1 = false, g_player_2 = false, g_player_mode_2 = false;