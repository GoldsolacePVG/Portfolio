void InitSprites(){
    g_selection_sprite = (esat::SpriteHandle*)calloc(6, sizeof(esat::SpriteHandle));
    g_explosion_anim_1 = (esat::SpriteHandle*)calloc(4, sizeof(esat::SpriteHandle));
    g_explosion_anim_2 = (esat::SpriteHandle*)calloc(4, sizeof(esat::SpriteHandle)); 
    g_explosion_anim_3 = (esat::SpriteHandle*)calloc(4, sizeof(esat::SpriteHandle));
    g_player = (esat::SpriteHandle*)calloc(16, sizeof(esat::SpriteHandle));
    g_diamond = (esat::SpriteHandle*)calloc(6, sizeof(esat::SpriteHandle));
    g_nuclear = (esat::SpriteHandle*)calloc(2, sizeof(esat::SpriteHandle));    
    g_triangle = (esat::SpriteHandle*)calloc(2, sizeof(esat::SpriteHandle));
    g_ship_explosion = (esat::SpriteHandle*)calloc(2, sizeof(esat::SpriteHandle));
    g_fireball_enemy = (esat::SpriteHandle*)calloc(16, sizeof(esat::SpriteHandle));
    g_fluff_enemy = (esat::SpriteHandle*)calloc(8, sizeof(esat::SpriteHandle));
    g_bubble_enemy = (esat::SpriteHandle*)calloc(8, sizeof(esat::SpriteHandle));
    g_plane_enemy = (esat::SpriteHandle*)calloc(10, sizeof(esat::SpriteHandle));
    g_ovni_enemy = (esat::SpriteHandle*)calloc(4, sizeof(esat::SpriteHandle));
    g_cross_enemy = (esat::SpriteHandle*)calloc(4, sizeof(esat::SpriteHandle));
    g_falcon_enemy = (esat::SpriteHandle*)calloc(8, sizeof(esat::SpriteHandle));
    g_glass_enemy = (esat::SpriteHandle*)calloc(4, sizeof(esat::SpriteHandle));

    g_jet = esat::SpriteFromFile("resources/img/jet.png"); //Img Menu 1
    g_jet_2 = esat::SpriteFromFile("resources/img/jet_2.png"); //Img Menu 2
    g_author = esat::SpriteFromFile("resources/img/rodri1.png"); //Author
    *(g_selection_sprite + 0) = esat::SpriteFromFile("resources/img/game_selec.png"); //Menu Selection 1
    *(g_selection_sprite + 1) = esat::SpriteFromFile("resources/img/player_mode_1.png"); //Menu Selection 2
    *(g_selection_sprite + 2) = esat::SpriteFromFile("resources/img/player_mode_1_1.png"); //Menu Selection 2.1
    *(g_selection_sprite + 3) = esat::SpriteFromFile("resources/img/player_mode_2.png"); //Menu Selection 3
    *(g_selection_sprite + 4) = esat::SpriteFromFile("resources/img/player_mode_2_1.png"); //Menu Selection 3.1
    *(g_selection_sprite + 5) = esat::SpriteFromFile("resources/img/copyright.png"); //Menu Selection 4
    g_1up = esat::SpriteFromFile("resources/img/1up.png"); //Sprite first player
    g_2up = esat::SpriteFromFile("resources/img/2up.png"); //Sprite second player
    g_hi = esat::SpriteFromFile("resources/img/HI.png"); //Sprite HIGH-SCORE
    g_live = esat::SpriteFromFile("resources/img/live.png"); //Sprite vidas
    *(g_player + 0) = esat::SpriteFromFile("resources/img/player_1_1.png"); //Normal left
    *(g_player + 1) = esat::SpriteFromFile("resources/img/player_1_2.png"); //Normal left
    *(g_player + 2) = esat::SpriteFromFile("resources/img/player_1_3.png"); //Normal left
    *(g_player + 3) = esat::SpriteFromFile("resources/img/player_1_4.png"); //Normal left
    *(g_player + 4) = esat::SpriteFromFile("resources/img/player_2_1.png"); //Normal right
    *(g_player + 5) = esat::SpriteFromFile("resources/img/player_2_2.png"); //Normal right
    *(g_player + 6) = esat::SpriteFromFile("resources/img/player_2_3.png"); //Normal right
    *(g_player + 7) = esat::SpriteFromFile("resources/img/player_2_4.png"); //Normal right
    *(g_player + 8) = esat::SpriteFromFile("resources/img/player_3_1.png"); //Jetpack left
    *(g_player + 9) = esat::SpriteFromFile("resources/img/player_3_2.png"); //Jetpack left
    *(g_player + 10) = esat::SpriteFromFile("resources/img/player_3_3.png"); //Jetpack left
    *(g_player + 11) = esat::SpriteFromFile("resources/img/player_3_4.png"); //Jetpack left
    *(g_player + 12) = esat::SpriteFromFile("resources/img/player_4_1.png"); //Jetpack right
    *(g_player + 13) = esat::SpriteFromFile("resources/img/player_4_2.png"); //Jetpack right
    *(g_player + 14) = esat::SpriteFromFile("resources/img/player_4_3.png"); //Jetpack right
    *(g_player + 15) = esat::SpriteFromFile("resources/img/player_4_4.png"); //Jetpack right
    g_ground_plat = esat::SpriteFromFile("resources/img/ground_platform.png"); //Ground
    g_small_plat = esat::SpriteFromFile("resources/img/small_platform.png"); //Small plat
    g_big_plat = esat::SpriteFromFile("resources/img/big_platform.png"); //Big plat
    g_fuel = esat::SpriteFromFile("resources/img/fuel.png"); //Fuel
    *(g_diamond + 0) = esat::SpriteFromFile("resources/img/diamond_1.png"); //Diamond 1
    *(g_diamond + 1) = esat::SpriteFromFile("resources/img/diamond_2.png"); //Diamond 2
    *(g_diamond + 2) = esat::SpriteFromFile("resources/img/diamond_3.png"); //Diamond 3
    *(g_diamond + 3) = esat::SpriteFromFile("resources/img/diamond_4.png"); //Diamond 4
    *(g_diamond + 4) = esat::SpriteFromFile("resources/img/diamond_5.png"); //Diamond 5
    *(g_diamond + 5) = esat::SpriteFromFile("resources/img/diamond_6.png"); //Diamond 6
    g_gold = esat::SpriteFromFile("resources/img/gold.png"); //Gold
    g_pearl = esat::SpriteFromFile("resources/img/pearl.png"); //Pearl
    *(g_nuclear + 0) = esat::SpriteFromFile("resources/img/nuclear_1.png"); //Nuclear 1
    *(g_nuclear + 1) = esat::SpriteFromFile("resources/img/nuclear_2.png"); //Nuclear 2
    *(g_triangle + 0) = esat::SpriteFromFile("resources/img/triangle_1.png"); //Triangle 1
    *(g_triangle + 1) = esat::SpriteFromFile("resources/img/triangle_2.png"); //Triangle 2
    *(g_fireball_enemy + 0) = esat::SpriteFromFile("resources/img/red_fireball_1.png"); //Red Fireball
    *(g_fireball_enemy + 1) = esat::SpriteFromFile("resources/img/red_fireball_2.png"); //Red Fireball
    *(g_fireball_enemy + 2) = esat::SpriteFromFile("resources/img/red_fireball_3.png"); //Red Fireball
    *(g_fireball_enemy + 3) = esat::SpriteFromFile("resources/img/red_fireball_4.png"); //Red Fireball
    *(g_fireball_enemy + 4) = esat::SpriteFromFile("resources/img/green_fireball_1.png"); //Green Fireball
    *(g_fireball_enemy + 5) = esat::SpriteFromFile("resources/img/green_fireball_2.png"); //Green Fireball
    *(g_fireball_enemy + 6) = esat::SpriteFromFile("resources/img/green_fireball_3.png"); //Green Fireball
    *(g_fireball_enemy + 7) = esat::SpriteFromFile("resources/img/green_fireball_4.png"); //Green Fireball
    *(g_fireball_enemy + 8) = esat::SpriteFromFile("resources/img/blue_fireball_1.png"); //Blue Fireball
    *(g_fireball_enemy + 9) = esat::SpriteFromFile("resources/img/blue_fireball_2.png"); //Blue Fireball
    *(g_fireball_enemy + 10) = esat::SpriteFromFile("resources/img/blue_fireball_3.png"); //Blue Fireball
    *(g_fireball_enemy + 11) = esat::SpriteFromFile("resources/img/blue_fireball_4.png"); //Blue Fireball
    *(g_fireball_enemy + 12) = esat::SpriteFromFile("resources/img/pink_fireball_1.png"); //Pink Fireball
    *(g_fireball_enemy + 13) = esat::SpriteFromFile("resources/img/pink_fireball_2.png"); //Pink Fireball
    *(g_fireball_enemy + 14) = esat::SpriteFromFile("resources/img/pink_fireball_3.png"); //Pink Fireball
    *(g_fireball_enemy + 15) = esat::SpriteFromFile("resources/img/pink_fireball_4.png"); //Pink Fireball
    *(g_fluff_enemy + 0) = esat::SpriteFromFile("resources/img/red_fluff_1.png"); //Red Fluff
    *(g_fluff_enemy + 1) = esat::SpriteFromFile("resources/img/red_fluff_2.png"); //Red Fluff
    *(g_fluff_enemy + 2) = esat::SpriteFromFile("resources/img/green_fluff_1.png"); //Green Fluff
    *(g_fluff_enemy + 3) = esat::SpriteFromFile("resources/img/green_fluff_2.png"); //Green Fluff
    *(g_fluff_enemy + 4) = esat::SpriteFromFile("resources/img/blue_fluff_1.png"); //Blue Fluff
    *(g_fluff_enemy + 5) = esat::SpriteFromFile("resources/img/blue_fluff_2.png"); //Blue Fluff
    *(g_fluff_enemy + 6) = esat::SpriteFromFile("resources/img/pink_fluff_1.png"); //Pink Fluff
    *(g_fluff_enemy + 7) = esat::SpriteFromFile("resources/img/pink_fluff_2.png"); //Pink Fluff
    *(g_bubble_enemy + 0) = esat::SpriteFromFile("resources/img/red_bubble_1.png"); //Red Bubble
    *(g_bubble_enemy + 1) = esat::SpriteFromFile("resources/img/red_bubble_2.png"); //Red Bubble
    *(g_bubble_enemy + 2) = esat::SpriteFromFile("resources/img/green_bubble_1.png"); //Green Bubble
    *(g_bubble_enemy + 3) = esat::SpriteFromFile("resources/img/green_bubble_2.png"); //Green Bubble
    *(g_bubble_enemy + 4) = esat::SpriteFromFile("resources/img/blue_bubble_1.png"); //Blue Bubble
    *(g_bubble_enemy + 5) = esat::SpriteFromFile("resources/img/blue_bubble_2.png"); //Blue Bubble
    *(g_bubble_enemy + 6) = esat::SpriteFromFile("resources/img/pink_bubble_1.png"); //Pink Bubble
    *(g_bubble_enemy + 7) = esat::SpriteFromFile("resources/img/pink_bubble_2.png"); //Pink Bubble
    *(g_plane_enemy + 0) = esat::SpriteFromFile("resources/img/red_plane_1.png"); // Red Plane
    *(g_plane_enemy + 1) = esat::SpriteFromFile("resources/img/red_plane_2.png"); // Red Plane
    *(g_plane_enemy + 2) = esat::SpriteFromFile("resources/img/green_plane_1.png"); // Green Plane
    *(g_plane_enemy + 3) = esat::SpriteFromFile("resources/img/green_plane_2.png"); // Green Plane
    *(g_plane_enemy + 4) = esat::SpriteFromFile("resources/img/blue_plane_1.png"); // Blue Plane
    *(g_plane_enemy + 5) = esat::SpriteFromFile("resources/img/blue_plane_2.png"); // Blue Plane
    *(g_plane_enemy + 6) = esat::SpriteFromFile("resources/img/pink_plane_1.png"); // Pink Plane
    *(g_plane_enemy + 7) = esat::SpriteFromFile("resources/img/pink_plane_2.png"); // Pink Plane
    *(g_plane_enemy + 8) = esat::SpriteFromFile("resources/img/white_plane_1.png"); //White Plane
    *(g_plane_enemy + 9) = esat::SpriteFromFile("resources/img/white_plane_2.png"); //White Plane
    *(g_ovni_enemy + 0) = esat::SpriteFromFile("resources/img/red_ovni.png"); //Red Ovni
    *(g_ovni_enemy + 1) = esat::SpriteFromFile("resources/img/green_ovni.png"); //Green Ovni
    *(g_ovni_enemy + 2) = esat::SpriteFromFile("resources/img/blue_ovni.png"); //Blue Ovni
    *(g_ovni_enemy + 3) = esat::SpriteFromFile("resources/img/pink_ovni.png"); //Pink Ovni
    *(g_cross_enemy + 0) = esat::SpriteFromFile("resources/img/red_cross.png"); //Red Cross
    *(g_cross_enemy + 1) = esat::SpriteFromFile("resources/img/green_cross.png"); //Green Cross
    *(g_cross_enemy + 2) = esat::SpriteFromFile("resources/img/blue_cross.png"); //Blue Cross
    *(g_cross_enemy + 3) = esat::SpriteFromFile("resources/img/pink_cross.png"); //Pink Cross
    *(g_falcon_enemy + 0) = esat::SpriteFromFile("resources/img/red_falcon_1.png"); //Red Falcon
    *(g_falcon_enemy + 1) = esat::SpriteFromFile("resources/img/red_falcon_2.png"); //Red Falcon
    *(g_falcon_enemy + 2) = esat::SpriteFromFile("resources/img/green_falcon_1.png"); //Green Falcon
    *(g_falcon_enemy + 3) = esat::SpriteFromFile("resources/img/green_falcon_2.png"); //Green Falcon
    *(g_falcon_enemy + 4) = esat::SpriteFromFile("resources/img/blue_falcon_1.png"); //Blue Falcon
    *(g_falcon_enemy + 5) = esat::SpriteFromFile("resources/img/blue_falcon_2.png"); //Blue Falcon
    *(g_falcon_enemy + 6) = esat::SpriteFromFile("resources/img/pink_falcon_1.png"); //Pink Falcon
    *(g_falcon_enemy + 7) = esat::SpriteFromFile("resources/img/pink_falcon_2.png"); //Pink Falcon
    *(g_glass_enemy + 0) = esat::SpriteFromFile("resources/img/red_glass.png"); //Red Glass
    *(g_glass_enemy + 1) = esat::SpriteFromFile("resources/img/green_glass.png"); //Green Glass
    *(g_glass_enemy + 2) = esat::SpriteFromFile("resources/img/blue_glass.png"); //Blue Glass
    *(g_glass_enemy + 3) = esat::SpriteFromFile("resources/img/pink_glass.png"); //Pink Glass
    g_ship1_1 = esat::SpriteFromFile("resources/img/ship1_1.png"); //Ship 1 parts
    g_ship1_2 = esat::SpriteFromFile("resources/img/ship1_2.png"); //Ship 1 parts
    g_ship1_3 = esat::SpriteFromFile("resources/img/ship1_3.png"); //Ship 1 parts
    g_ship2_1 = esat::SpriteFromFile("resources/img/ship_2_1.png"); //Ship 2 parts
    g_ship2_2 = esat::SpriteFromFile("resources/img/ship_2_2.png"); //Ship 2 parts
    g_ship2_3 = esat::SpriteFromFile("resources/img/ship_2_3.png"); //Ship 2 parts
    g_ship3_1 = esat::SpriteFromFile("resources/img/ship3_1.png"); // Ship 3 parts
    g_ship3_2 = esat::SpriteFromFile("resources/img/ship3_2.png"); // Ship 3 parts
    g_ship3_3 = esat::SpriteFromFile("resources/img/ship3_3.png"); // Ship 3 parts
    g_ship4_1 = esat::SpriteFromFile("resources/img/ship4_1.png"); // Ship 4 parts
    g_ship4_2 = esat::SpriteFromFile("resources/img/ship4_2.png"); // Ship 4 parts
    g_ship4_3 = esat::SpriteFromFile("resources/img/ship4_3.png"); // Ship 4 parts
    g_full_ship_1_1 = esat::SpriteFromFile("resources/img/fuel_ship1_1.png"); //Ship 1.1 part & fuel
    g_full_ship_1_2 = esat::SpriteFromFile("resources/img/fuel_ship1_2.png"); //Ship 1.2 part & fuel
    g_full_ship_1_3 = esat::SpriteFromFile("resources/img/fuel_ship1_3.png"); //Ship 1.3 part & fuel
    g_full_ship_1_4 = esat::SpriteFromFile("resources/img/fuel_ship1_4.png"); //Ship 1.4 part & fuel
    g_full_ship_1_5 = esat::SpriteFromFile("resources/img/fuel_ship1_5.png"); //Ship 1.5 part & fuel
    g_full_ship_1_6 = esat::SpriteFromFile("resources/img/fuel_ship1_6.png"); //Ship 1.6 part & fuel
    g_full_ship_2_1 = esat::SpriteFromFile("resources/img/fuel_ship_2_1.png"); // Ship 2.1 part & fuel
    g_full_ship_2_2 = esat::SpriteFromFile("resources/img/fuel_ship_2_2.png"); // Ship 2.2 part & fuel
    g_full_ship_2_3 = esat::SpriteFromFile("resources/img/fuel_ship_2_3.png"); // Ship 2.3 part & fuel
    g_full_ship_2_4 = esat::SpriteFromFile("resources/img/fuel_ship_2_4.png"); // Ship 2.4 part & fuel
    g_full_ship_2_5 = esat::SpriteFromFile("resources/img/fuel_ship_2_5.png"); // Ship 2.5 part & fuel
    g_full_ship_2_6 = esat::SpriteFromFile("resources/img/fuel_ship_2_6.png"); // Ship 2.6 part & fuel
    g_full_ship_3_1 = esat::SpriteFromFile("resources/img/fuel_ship_3_1.png"); // Ship 3.1 part & fuel
    g_full_ship_3_2 = esat::SpriteFromFile("resources/img/fuel_ship_3_2.png"); // Ship 3.2 part & fuel
    g_full_ship_3_3 = esat::SpriteFromFile("resources/img/fuel_ship_3_3.png"); // Ship 3.3 part & fuel
    g_full_ship_3_4 = esat::SpriteFromFile("resources/img/fuel_ship_3_4.png"); // Ship 3.4 part & fuel
    g_full_ship_3_5 = esat::SpriteFromFile("resources/img/fuel_ship_3_5.png"); // Ship 3.5 part & fuel
    g_full_ship_3_6 = esat::SpriteFromFile("resources/img/fuel_ship_3_6.png"); // Ship 3.6 part & fuel
    g_full_ship_4_1 = esat::SpriteFromFile("resources/img/fuel_ship_4_1.png"); // Ship 4.1 part & fuel
    g_full_ship_4_2 = esat::SpriteFromFile("resources/img/fuel_ship_4_2.png"); // Ship 4.2 part & fuel
    g_full_ship_4_3 = esat::SpriteFromFile("resources/img/fuel_ship_4_3.png"); // Ship 4.3 part & fuel
    g_full_ship_4_4 = esat::SpriteFromFile("resources/img/fuel_ship_4_4.png"); // Ship 4.4 part & fuel
    g_full_ship_4_5 = esat::SpriteFromFile("resources/img/fuel_ship_4_5.png"); // Ship 4.5 part & fuel
    g_full_ship_4_6 = esat::SpriteFromFile("resources/img/fuel_ship_4_6.png"); // Ship 4.6 part & fuel
    *(g_ship_explosion + 0) = esat::SpriteFromFile("resources/img/ship_explosion_1.png"); //Ship fire 
    *(g_ship_explosion + 1) = esat::SpriteFromFile("resources/img/ship_explosion_2.png"); //Ship fire 
    g_shield = esat::SpriteFromFile("resources/img/spr_shield.png"); //Shield
    *(g_explosion_anim_1 + 0) = esat::SpriteFromFile("resources/img/white_explosion_3.png"); //Explosion white
    *(g_explosion_anim_1 + 1) = esat::SpriteFromFile("resources/img/red_explosion_3.png"); // Explosion white
    *(g_explosion_anim_1 + 2) = esat::SpriteFromFile("resources/img/pink_explosion_3.png"); //Explosion white
    *(g_explosion_anim_1 + 3) = esat::SpriteFromFile("resources/img/yellow_explosion_3.png"); //Explosion red
    *(g_explosion_anim_2 + 0) = esat::SpriteFromFile("resources/img/red_explosion_2.png"); //Explosion red
    *(g_explosion_anim_2 + 1) = esat::SpriteFromFile("resources/img/white_explosion_2.png"); // Explosion red
    *(g_explosion_anim_2 + 2) = esat::SpriteFromFile("resources/img/pink_explosion_2.png"); //Explosion pink
    *(g_explosion_anim_2 + 3) = esat::SpriteFromFile("resources/img/yellow_explosion_2.png"); //Explosion pink
    *(g_explosion_anim_3 + 0) = esat::SpriteFromFile("resources/img/pink_explosion_1.png"); //Explosion pink
    *(g_explosion_anim_3 + 1) = esat::SpriteFromFile("resources/img/yellow_explosion_1.png"); //Explosion yellow
    *(g_explosion_anim_3 + 2) = esat::SpriteFromFile("resources/img/red_explosion_1.png"); //Explosion yellow
    *(g_explosion_anim_3 + 3) = esat::SpriteFromFile("resources/img/white_explosion_1.png"); //Explosion yellow
}

void ReleaseSprites(){
    esat::SpriteRelease(g_jet);
    esat::SpriteRelease(g_jet_2);
    esat::SpriteRelease(g_1up);
    esat::SpriteRelease(g_2up);
    esat::SpriteRelease(g_hi);
    esat::SpriteRelease(g_live);
    esat::SpriteRelease(g_ground_plat);
    esat::SpriteRelease(g_small_plat);
    esat::SpriteRelease(g_big_plat);
    esat::SpriteRelease(g_fuel);
    esat::SpriteRelease(g_gold);
    esat::SpriteRelease(g_pearl);
    esat::SpriteRelease(g_ship1_1);
    esat::SpriteRelease(g_ship1_2);
    esat::SpriteRelease(g_ship1_3);
    esat::SpriteRelease(g_ship2_1);
    esat::SpriteRelease(g_ship2_2);
    esat::SpriteRelease(g_ship2_3);
    esat::SpriteRelease(g_ship3_1);
    esat::SpriteRelease(g_ship3_2);
    esat::SpriteRelease(g_ship3_3);
    esat::SpriteRelease(g_full_ship_1_1);
    esat::SpriteRelease(g_full_ship_1_2);
    esat::SpriteRelease(g_full_ship_1_3);
    esat::SpriteRelease(g_full_ship_1_4);
    esat::SpriteRelease(g_full_ship_1_5);
    esat::SpriteRelease(g_full_ship_1_6);
    esat::SpriteRelease(g_full_ship_2_1);
    esat::SpriteRelease(g_full_ship_2_2);
    esat::SpriteRelease(g_full_ship_2_3);
    esat::SpriteRelease(g_full_ship_2_4);
    esat::SpriteRelease(g_full_ship_2_5);
    esat::SpriteRelease(g_full_ship_2_6);
    esat::SpriteRelease(g_full_ship_3_1);
    esat::SpriteRelease(g_full_ship_3_2);
    esat::SpriteRelease(g_full_ship_3_3);
    esat::SpriteRelease(g_full_ship_3_4);
    esat::SpriteRelease(g_full_ship_3_5);
    esat::SpriteRelease(g_full_ship_3_6);
    esat::SpriteRelease(g_full_ship_4_1);
    esat::SpriteRelease(g_full_ship_4_2);
    esat::SpriteRelease(g_full_ship_4_3);
    esat::SpriteRelease(g_full_ship_4_4);
    esat::SpriteRelease(g_full_ship_4_5);
    esat::SpriteRelease(g_full_ship_4_6);
    esat::SpriteRelease(g_shield);
}