void InitMemoryItem(){item = (TItems1 *)calloc(9, sizeof(TItems1));}

void InitShip(int type){
    // SHIP 1
    (item + 0)->position.x = kWindowWidth - 335;
    (item + 0)->position.y = kWindowHeight - 85;
    switch(type){
        case 1:
            (item + 0)->sprite = &g_ship1_1;
        break;
        case 2:
            (item + 0)->sprite = &g_ship2_1;
        break;
        case 3:
            (item + 0)->sprite = &g_ship3_1;
        break;
        case 4:
            (item + 0)->sprite = &g_ship4_1;
        break;
    }
    (item + 0)->size = {(float)esat::SpriteWidth(*(item + 0)->sprite), (float)esat::SpriteHeight(*(item + 0)->sprite)};
    (item + 0)->is_alive = true;
    (item + 0)->can_move = false;

    // SHIP 2
    (item + 1)->position.x = kWindowWidth / 2 - 20;
    (item + 1)->position.y = kWindowHeight / 2 - 57;
    switch(type){
        case 1:
            (item + 1)->sprite = &g_ship1_2;
        break;
        case 2:
            (item + 1)->sprite = &g_ship2_2;
        break;
        case 3:
            (item + 1)->sprite = &g_ship3_2;
        break;
        case 4:
            (item + 1)->sprite = &g_ship4_2;
        break;
    }
    (item + 1)->size = {(float)esat::SpriteWidth(*(item + 1)->sprite), (float)esat::SpriteHeight(*(item + 1)->sprite)};
    (item + 1)->score = 100;
    (item + 1)->is_alive = true;
    (item + 1)->taken = false;
    (item + 1)->has_arrived = false;
    (item + 1)->falling = false;
    (item + 1)->can_move = false;
    (item + 1)->picked = false;

    // SHIP 3
    (item + 2)->position.x = 170;
    (item + 2)->position.y = 243;
    switch(type){
        case 1:
            (item + 2)->sprite = &g_ship1_3;
        break;
        case 2:
            (item + 2)->sprite = &g_ship2_3;
        break;
        case 3:
            (item + 2)->sprite = &g_ship3_3;
        break;
        case 4:
            (item + 2)->sprite = &g_ship4_3;
        break;
    }
    (item + 2)->size = {(float)esat::SpriteWidth(*(item + 2)->sprite), (float)esat::SpriteHeight(*(item + 2)->sprite)};
    (item + 2)->score = 100;
    (item + 2)->is_alive = true;
    (item + 2)->taken = false;
    (item + 2)->has_arrived = false;
    (item + 2)->falling = false;
    (item + 2)->can_move = false;
    (item + 2)->picked = false;
}

void InitItems(){
    //FUEL
    (item + 3)->position.y = 53;
    (item + 3)->sprite = &g_fuel;
    (item + 3)->size = {(float)esat::SpriteWidth(g_fuel), (float)esat::SpriteHeight(g_fuel)};
    (item + 3)->score = 100;
    (item + 3)->speed = 6;
    (item + 3)->is_alive = false;
    (item + 3)->is_ready = true;
    (item + 3)->can_move = false;
    (item + 3)->taken = false;
    (item + 3)->has_arrived = false;
    (item + 3)->falling = false;
    (item + 3)->picked = false;
    
    //DIAMOND
    (item + 4)->position.y = 53;
    (item + 4)->sprite = g_diamond;
    (item + 4)->size = {(float)esat::SpriteWidth(*(item + 4)->sprite), (float)esat::SpriteHeight(*(item + 4)->sprite)};
    (item + 4)->score = 250;
    (item + 4)->speed = 6;
    (item + 4)->is_alive = false;
    (item + 4)->is_ready = true;
    (item + 4)->can_move = false;

    //PEARL
    (item + 5)->position.y = 53;
    (item + 5)->sprite = &g_pearl;
    (item + 5)->size = {(float)esat::SpriteWidth(*(item + 5)->sprite), (float)esat::SpriteHeight(*(item + 5)->sprite)};
    (item + 5)->score = 250;
    (item + 5)->speed = 6;
    (item + 5)->is_alive = false;
    (item + 5)->is_ready = true;
    (item + 5)->can_move = false;

    //GOLD
    (item + 6)->position.y = 53;
    (item + 6)->sprite = &g_gold;
    (item + 6)->size = {(float)esat::SpriteWidth(*(item + 6)->sprite), (float)esat::SpriteHeight(*(item + 6)->sprite)};
    (item + 6)->score = 250;
    (item + 6)->speed = 6;
    (item + 6)->is_alive = false;
    (item + 6)->is_ready = true;
    (item + 6)->can_move = false;

    //NUCLEAR REACTOR
    (item + 7)->position.y = 53;
    (item + 7)->sprite = g_nuclear;
    (item + 7)->size = {(float)esat::SpriteWidth(*(item + 7)->sprite), (float)esat::SpriteHeight(*(item + 7)->sprite)};
    (item + 7)->score = 250;
    (item + 7)->speed = 6;
    (item + 7)->count = 0;
    (item + 7)->is_alive = false;
    (item + 7)->is_ready = true;
    (item + 7)->can_move = false;

    //TRIANGLE
    (item + 8)->position.y = 53;
    (item + 8)->sprite = g_triangle;
    (item + 8)->size = {(float)esat::SpriteWidth(*(item + 8)->sprite), (float)esat::SpriteHeight(*(item + 8)->sprite)};
    (item + 8)->score = 250;
    (item + 8)->speed = 6;
    (item + 8)->count = 0;
    (item + 8)->is_alive = false;
    (item + 8)->is_ready = true;
    (item + 8)->can_move = false;
}

void UpdateItems(){
    //SHIP 2
    if((item + 1)->is_alive && (item + 1)->can_move){
        (item + 1)->position.y += kGravity;
    }
    if((item + 1)->taken){
        (item + 1)->position.x = player.position.x;
        (item + 1)->position.y = player.position.y;
    }
    if(player.ship_level < 5){
        if(((item + 1)->position.x >= (item + 0)->position.x && (item + 1)->position.x <= (item + 0)->position.x + (item + 0)->size.x) && ((item + 1)->position.y + (item + 1)->size.y) <= (item + 0)->position.y){
            (item + 1)->taken = false;
            (item + 1)->falling = true;
            (item + 1)->position.x = (item + 0)->position.x;
        }
    }
    if(player.ship_level >= 5 && player.ship_level < 9){
        if(((item + 1)->position.x >= (item + 0)->position.x && (item + 1)->position.x <= (item + 0)->position.x + (item + 0)->size.x) && ((item + 1)->position.y + (item + 1)->size.y) <= (item + 0)->position.y){
            (item + 1)->taken = false;
            (item + 1)->falling = true;
            (item + 1)->position.x = (item + 0)->position.x + 15;
        }
    }
    if(player.ship_level >= 9 && player.ship_level < 13){
        if(((item + 1)->position.x >= (item + 0)->position.x && (item + 1)->position.x <= (item + 0)->position.x + (item + 0)->size.x) && ((item + 1)->position.y + (item + 1)->size.y) <= (item + 0)->position.y){
            (item + 1)->taken = false;
            (item + 1)->falling = true;
            (item + 1)->position.x = (item + 0)->position.x;
        }
    }
    if(player.ship_level >= 13 && player.ship_level < 17){
        if(((item + 1)->position.x >= (item + 0)->position.x && (item + 1)->position.x <= (item + 0)->position.x + (item + 0)->size.x) && ((item + 1)->position.y + (item + 1)->size.y) <= (item + 0)->position.y){
            (item + 1)->taken = false;
            (item + 1)->falling = true;
            (item + 1)->position.x = (item + 0)->position.x;
        }
    }
    if ((((item + 1)->position.y + (item + 1)->size.y) >= (item + 0)->position.y) && ((item + 1)->position.x >= (item + 0)->position.x && (item + 1)->position.x <= (item + 0)->position.x + (item + 0)->size.x)){
        (item + 1)->has_arrived = true;
        (item + 1)->can_move = false;
    }

    // SHIP 3
    if((item + 2)->is_alive && (item + 2)->can_move){
        (item + 2)->position.y += kGravity;
    }
    if((item + 2)->taken){
        (item + 2)->position.x = player.position.x;
        (item + 2)->position.y = player.position.y;
    }
    if(player.ship_level < 5){
        if(((item + 2)->position.x >= (item + 1)->position.x && (item + 2)->position.x <= (item + 1)->position.x + (item + 1)->size.x) && (((item + 2)->position.y + 2) + (item + 2)->size.y) <= (item + 1)->position.y && (item + 2)->taken){
            (item + 2)->taken = false;
            (item + 2)->falling = true;
            (item + 2)->position.x = (item + 1)->position.x + 18;
        }
    }
    if(player.ship_level >= 5 && player.ship_level < 9){
        if (((item + 2)->position.x >= (item + 1)->position.x && (item + 2)->position.x <= (item + 1)->position.x + (item + 1)->size.x) && (((item + 2)->position.y + 2) + (item + 2)->size.y) <= (item + 1)->position.y && (item + 2)->taken){
            (item + 2)->taken = false;
            (item + 2)->falling = true;
            (item + 2)->position.x = (item + 1)->position.x;
        }
    }
    if(player.ship_level >= 9 && player.ship_level < 13){
        if (((item + 2)->position.x >= (item + 1)->position.x && (item + 2)->position.x <= (item + 1)->position.x + (item + 1)->size.x) && (((item + 2)->position.y + 2) + (item + 2)->size.y) <= (item + 1)->position.y && (item + 2)->taken){
            (item + 2)->taken = false;
            (item + 2)->falling = true;
            (item + 2)->position.x = (item + 1)->position.x + 4;
        }
    }
    if(player.ship_level >= 13 && player.ship_level < 17){
        if (((item + 2)->position.x >= (item + 1)->position.x && (item + 2)->position.x <= (item + 1)->position.x + (item + 1)->size.x) && (((item + 2)->position.y + 2) + (item + 2)->size.y) <= (item + 1)->position.y && (item + 2)->taken){
            (item + 2)->taken = false;
            (item + 2)->falling = true;
            (item + 2)->position.x = (item + 1)->position.x + 12;
        }
    }
    if((((item + 2)->position.y + 2) + (item + 2)->size.y) >= (item + 1)->position.y && (item + 2)->falling){
        (item + 2)->has_arrived = true;
        (item + 2)->can_move = false;
    }

    //GENERAL SHIP
    if((item + 1)->has_arrived && (item + 2)->has_arrived){
        g_ship_complete = true;
    }

    //////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////

    if(g_ship_complete && !g_ship_full && !g_landing){
        //FUEL
        (item + 3)->spawn = rand()%10;
        (item + 3)->aux = rand()%926;
        if(!(item + 3)->is_alive && (item + 3)->is_ready && (item + 3)->spawn == 1 && !g_fuel_t || esat::IsSpecialKeyDown(esat::kSpecialKey_Enter)){
            SetFuel();
        }
        if((item + 3)->is_alive && !(item + 3)->is_ready && (item + 3)->can_move){
            (item + 3)->position.y += (item + 3)->speed;
        }
        if((item + 3)->taken){
            (item + 3)->position.x = player.position.x;
            (item + 3)->position.y = player.position.y;
        }
        if(((item + 3)->position.x >= (item + 1)->position.x && (item + 3)->position.x <= (item + 1)->position.x + (item + 1)->size.x) && (((item + 3)->position.y + 1) + (item + 3)->size.y) <= (item + 1)->position.y && (item + 3)->taken){
            (item + 3)->taken = false;
            (item + 3)->falling = true;
            (item + 3)->position.x = (item + 1)->position.x;
        }
        if(((item + 3)->position.y + (item + 3)->size.y) >= (item + 2)->position.y && (item + 3)->falling){
            g_fuel_counter++;
            (item + 3)->has_arrived = true;
            (item + 3)->is_alive = false;
            (item + 3)->is_ready = true;
            g_fuel_t = false;
            (item + 3)->position.y = 53;
        }
        if(g_fuel_counter == 1){
            g_shipfull_alive_1 = true; 
        }
        if(g_fuel_counter == 2){
            g_shipfull_alive_2 = true;
        }
        if(g_fuel_counter == 3){
            g_shipfull_alive_3 = true;
        }
        if(g_fuel_counter == 4){
            g_shipfull_alive_4 = true;
        }
        if(g_fuel_counter == 5){
            g_shipfull_alive_5 = true;
        }
        if(g_fuel_counter == 6){
            g_shipfull_alive_6 = true;
            g_ship_full = true;
        }

        //DIAMOND
        (item + 4)->spawn = rand()%50;
        (item + 4)->aux = rand()%926;
        if(!(item + 4)->is_alive && (item + 4)->is_ready && (item + 4)->spawn == 1 && !g_pearl_t 
            && !g_gold_t && !g_triangle_t && !g_nuclear_t){
            SetDiamond();
        }
        if((item + 4)->is_alive && !(item + 4)->is_ready && (item + 4)->can_move){
            (item + 4)->position.y += (item + 4)->speed;
        }
        if((item + 4)->is_alive && !(item + 4)->is_ready){
            (item + 4)->count++;
            if((item + 4)->count <= 5){
                (item + 4)->sprite = (g_diamond + 0);
            }
            if((item + 4)->count > 5 && (item + 4)->count <= 10){
                (item + 4)->sprite = (g_diamond + 1);
            }
            if((item + 4)->count > 10 && (item + 4)->count <= 15){
                (item + 4)->sprite = (g_diamond + 2);
            }
            if((item + 4)->count > 15 && (item + 4)->count <= 20){
                (item + 4)->sprite = (g_diamond + 3);
            }
            if((item + 4)->count > 20 && (item + 4)->count <= 25){
                (item + 4)->sprite = (g_diamond + 4);
            }
            if((item + 4)->count > 25 && (item + 4)->count <= 30){
                (item + 4)->sprite = (g_diamond + 5);
            }
            if((item + 4)->count == 30){
                (item + 4)->count = 0;
            }
        }

        //PEARL
        (item + 5)->spawn = rand() % 45;
        (item + 5)->aux = rand() % 926;
        if(!(item + 5)->is_alive && (item + 5)->is_ready && (item + 5)->spawn == 1 && !g_diamond_t 
            && !g_gold_t && !g_triangle_t && !g_nuclear_t){
            SetPearl();
        }
        if ((item + 5)->is_alive && !(item + 5)->is_ready && (item + 5)->can_move){
            (item + 5)->position.y += (item + 5)->speed;
        }

        //GOLD
        (item + 6)->spawn = rand()%65;
        (item + 6)->aux = rand()%926;
        if(!(item + 6)->is_alive && (item + 6)->is_ready && (item + 6)->spawn == 1 && !g_diamond_t 
           && !g_pearl_t && !g_triangle_t && !g_nuclear_t){
            SetGold();
        }
        if((item + 6)->is_alive && !(item + 6)->is_ready && (item + 6)->can_move){
            (item + 6)->position.y += (item + 6)->speed;
        }

        //NUCLEAR REACTOR
        (item + 7)->spawn = rand() % 130;
        (item + 7)->aux = rand() % 926;
        if(!(item + 7)->is_alive && (item + 7)->is_ready && (item + 7)->spawn == 1 && !g_diamond_t 
           && !g_pearl_t && !g_triangle_t && !g_gold_t){
            SetNuclear();
        }
        if((item + 7)->is_alive && !(item + 7)->is_ready && (item + 7)->can_move){
            (item + 7)->position.y += (item + 7)->speed;
        }

        if ((item + 7)->is_alive && !(item + 7)->is_ready){
            g_item_counter++;
            (item + 7)->count++;
            if((item + 7)->count <= 10){
                (item + 7)->sprite = (g_nuclear + 0);
            }
            if((item + 7)->count > 10){
                (item + 7)->sprite = (g_nuclear + 1);
            }
            if((item + 7)->count == 20){
                (item + 7)->count = 0;
            }
        }

        //TRIANGLE
        (item + 8)->spawn = rand() % 130;
        (item + 8)->aux = rand() % 926;
        if(!(item + 8)->is_alive && (item + 8)->is_ready && (item + 8)->spawn == 1 && !g_diamond_t && !g_pearl_t && !g_nuclear_t && !g_gold_t){
            SetTriangle();
        }
        if((item + 8)->is_alive && !(item + 8)->is_ready && (item + 8)->can_move){
            (item + 8)->position.y += (item + 8)->speed;
        }

        if((item + 8)->is_alive && !(item + 8)->is_ready){
            g_item_counter++;
            (item + 8)->count++;
            if((item + 8)->count <= 10){
                (item + 8)->sprite = (g_triangle + 0);
            }
            if((item + 8)->count > 10){
                (item + 8)->sprite = (g_triangle + 1);
            }
            if((item + 8)->count == 20){
                (item + 8)->count = 0;
            }
        }
    }
    // ITEM COLLISION GENERAL
    for (int i = 0; i < 9; i++){
        if ((item + i)->is_alive){
            ItemToPlatformCollision(i);
        }
    }

    if(g_ship_full){
        g_diamond_t = true, g_pearl_t = true, g_gold_t = true, g_nuclear_t = true, g_triangle_t = true;
        for(int k = 3; k < 9; k++){
            (item + k)->is_alive = false;
        }
        g_full_counter++;
        if(g_full_counter < 5){
            g_shipfull_alive_1 = true;
            g_shipfull_alive_2 = true;
            g_shipfull_alive_3 = true;
            g_shipfull_alive_4 = true;
            g_shipfull_alive_5 = true;
            g_shipfull_alive_6 = true;
        }
        if(g_full_counter >= 5 && g_full_counter < 10){
            g_shipfull_alive_1 = false;
            g_shipfull_alive_2 = false;
            g_shipfull_alive_3 = false;
            g_shipfull_alive_4 = false;
            g_shipfull_alive_5 = false;
            g_shipfull_alive_6 = false;
        }
        if(g_full_counter == 10){g_full_counter = 0;}
        if(((player.position.x + player.size.x) >= (item + 0)->position.x && player.position.x <= ((item + 0)->position.x + (item + 0)->size.x) && (player.position.y + player.size.y >= (item + 2)->position.y)) && (item + 0)->position.y > 0){
            player.is_alive = false;
            g_immortal = false;
            if(g_audio_dep){
                soloud.play(spacedep1);
            }
            g_audio_dep = false;
            for(int t = 0; t < 6; t++){
                if(!(mobs + t)->is_alive){
                    (mobs + t)->is_ready = false;
                }
            }
            for(int j = 0; j < 3; j++){
                (item + j)->position.y -= 2;
                if(((map + 0)->position.y - ((item + 0)->position.y + (item + 0)->size.y)) >= 60){
                    g_ship_exp_alive = true;
                }
            }
        }
    }
    if(g_ship_exp_alive){
        g_ship_explosion_counter++;
        if(g_ship_explosion_counter < 5){
            g_aux = *(g_ship_explosion + 0);
        }
        if(g_ship_explosion_counter >= 5 && g_ship_explosion_counter < 10){
            g_aux = *(g_ship_explosion + 1);
        }
        if(g_ship_explosion_counter == 10){
            g_ship_explosion_counter = 0;
        }
    }

    if((item + 0)->position.y <= 0){
        soloud.stopAudioSource(spacedep1);
        g_audio_dep = true;
        if(player.ship_level != 5 && player.ship_level != 9 && player.ship_level != 13 && player.ship_level != 17){
            g_landing = true;
        }
        g_ship_full = false;
        g_fuel_counter = 0;
        g_shipfull_alive_1 = false;
        g_shipfull_alive_2 = false;
        g_shipfull_alive_3 = false;
        g_shipfull_alive_4 = false;
        g_shipfull_alive_5 = false;
        g_shipfull_alive_6 = false;
        player.position.x = kWindowWidth/2;
        player.position.y = kWindowHeight - 110;
        for(int i = 0; i < 6; i++){
            (mobs + i)->is_alive = false;
        }
        if(!g_aux_land_bool){
            player.lives++;
            player.level++;
            player.ship_level++;
        }
        g_aux_land_bool = true;
        if(player.level == 9){player.level = 1;}
        if(player.ship_level == 17){player.ship_level = 1;}
        if(player.ship_level == 5){
            g_ship_complete = false;
            InitShip(2);
        }
        if(player.ship_level == 9){
            g_ship_complete = false;
            InitShip(3);
        }
        if(player.ship_level == 13){
            g_ship_complete = false;
            InitShip(4);
        }
        if(player.ship_level == 1){
            g_ship_complete = false;
            InitShip(1);
        }
    }
    if(g_landing){
        if(g_audio_land){
            soloud.play(spaceshipland);
        }
        g_audio_land = false;
        for(int k = 0; k < 3; k++){
            if(((item + 0)->position.y + (item + 0)->size.y) <= 767){
                (item + k)->position.y += 2;
                if(((item + 0)->position.y + (item + 0)->size.y) >= 767){
                    if(((item + 0)->position.y + (item + 0)->size.y) >= 715){
                        g_ship_exp_alive = false;
                    }
                    soloud.stopAudioSource(spaceshipland);
                    g_landing = false;
                    player.is_alive = true;
                    g_immortal = true;
                    g_diamond_t = false;
                    g_pearl_t = false;
                    g_gold_t = false;
                    g_nuclear_t = false;
                    g_triangle_t = false;
                    g_audio_land = true;
                    g_aux_land_bool = false;
                    for(int o = 3; o < 9; o++){
                        (item + o)->is_ready = true;
                        (item + o)->position.y = 53;
                    }
                    for(int j = 0; j < 5; j++){
                        (mobs + j)->is_ready = true;
                    }
                }
            }
        }
    }
}

void DrawItems(){
    //SHIP 1
    if((item + 0)->is_alive){esat::DrawSprite(*(item + 0)->sprite, (item + 0)->position.x, (item + 0)->position.y);}

    //SHIP 2
    if((item + 1)->is_alive){esat::DrawSprite(*(item + 1)->sprite, (item + 1)->position.x, (item + 1)->position.y);}

    //SHIP 3
    if((item + 2)->is_alive){esat::DrawSprite(*(item + 2)->sprite, (item + 2)->position.x, (item + 2)->position.y);}

    if(g_shipfull_alive_1 && player.ship_level < 5){esat::DrawSprite(g_full_ship_1_1, (item + 0)->position.x, (item + 0)->position.y + 23);}
    if(g_shipfull_alive_1 && player.ship_level >= 5 && player.ship_level < 9){esat::DrawSprite(g_full_ship_2_1, (item + 0)->position.x, (item + 0)->position.y + 17);}
    if(g_shipfull_alive_1 && player.ship_level >= 9 && player.ship_level < 13){esat::DrawSprite(g_full_ship_3_1, (item + 0)->position.x, (item + 0)->position.y + 20);}
    if(g_shipfull_alive_1 && player.ship_level >= 13 && player.ship_level < 17){esat::DrawSprite(g_full_ship_4_1, (item + 0)->position.x, (item + 0)->position.y + 21);}

    if(g_shipfull_alive_2 && player.ship_level < 5){esat::DrawSprite(g_full_ship_1_2, (item + 0)->position.x, (item + 0)->position.y);}
    if(g_shipfull_alive_2 && player.ship_level >= 5 && player.ship_level < 9){esat::DrawSprite(g_full_ship_2_2, (item + 0)->position.x, (item + 0)->position.y);}
    if(g_shipfull_alive_2 && player.ship_level >= 9 && player.ship_level < 13){esat::DrawSprite(g_full_ship_3_2, (item + 0)->position.x, (item + 0)->position.y);}
    if(g_shipfull_alive_2 && player.ship_level >= 13 && player.ship_level < 17){esat::DrawSprite(g_full_ship_4_2, (item + 0)->position.x, (item + 0)->position.y);}

    if(g_shipfull_alive_3 && player.ship_level < 5){esat::DrawSprite(g_full_ship_1_3, (item + 1)->position.x, (item + 0)->position.y - 28);}
    if(g_shipfull_alive_3 && player.ship_level >= 5 && player.ship_level < 9){esat::DrawSprite(g_full_ship_2_3, (item + 1)->position.x, (item + 0)->position.y - 28);}
    if(g_shipfull_alive_3 && player.ship_level >= 9 && player.ship_level < 13){esat::DrawSprite(g_full_ship_3_3, (item + 1)->position.x, (item + 0)->position.y - 28);}
    if(g_shipfull_alive_3 && player.ship_level >= 13 && player.ship_level < 17){esat::DrawSprite(g_full_ship_4_3, (item + 1)->position.x, (item + 0)->position.y - 25);}

    if(g_shipfull_alive_4 && player.ship_level < 5){esat::DrawSprite(g_full_ship_1_4, (item + 1)->position.x, (item + 1)->position.y);}
    if(g_shipfull_alive_4 && player.ship_level >= 5 && player.ship_level < 9){esat::DrawSprite(g_full_ship_2_4, (item + 1)->position.x, (item + 1)->position.y);}
    if(g_shipfull_alive_4 && player.ship_level >= 9 && player.ship_level < 13){esat::DrawSprite(g_full_ship_3_4, (item + 1)->position.x, (item + 1)->position.y);}
    if(g_shipfull_alive_4 && player.ship_level >= 13 && player.ship_level < 17){esat::DrawSprite(g_full_ship_4_4, (item + 1)->position.x, (item + 1)->position.y);}

    if(g_shipfull_alive_5 && player.ship_level < 5){esat::DrawSprite(g_full_ship_1_5, (item + 2)->position.x, (item + 1)->position.y - 29);}
    if(g_shipfull_alive_5 && player.ship_level >= 5 && player.ship_level < 9){esat::DrawSprite(g_full_ship_2_5, (item + 2)->position.x, (item + 1)->position.y - 31);}
    if(g_shipfull_alive_5 && player.ship_level >= 9 && player.ship_level < 13){esat::DrawSprite(g_full_ship_3_5, (item + 2)->position.x, (item + 1)->position.y - 29);}
    if(g_shipfull_alive_5 && player.ship_level >= 13 && player.ship_level < 17){esat::DrawSprite(g_full_ship_4_5, (item + 2)->position.x, (item + 1)->position.y - 25);}

    if(g_shipfull_alive_6 && player.ship_level < 5){esat::DrawSprite(g_full_ship_1_6, (item + 2)->position.x, (item + 2)->position.y);}
    if(g_shipfull_alive_6 && player.ship_level >= 5 && player.ship_level < 9){esat::DrawSprite(g_full_ship_2_6, (item + 2)->position.x, (item + 2)->position.y);}
    if(g_shipfull_alive_6 && player.ship_level >= 9 && player.ship_level < 13){esat::DrawSprite(g_full_ship_3_6, (item + 2)->position.x, (item + 2)->position.y);}
    if(g_shipfull_alive_6 && player.ship_level >= 13 && player.ship_level < 17){esat::DrawSprite(g_full_ship_4_6, (item + 2)->position.x, (item + 2)->position.y);}

    if(g_ship_exp_alive){esat::DrawSprite(g_aux, (item + 0)->position.x + 5, (item + 0)->position.y + (item + 0)->size.y + 10);}

    //GENERAL ITEMS
    for(int i = 3; i < 9; i++){
        if((item + i)->is_alive && !(item + i)->is_ready){esat::DrawSprite(*(item + i)->sprite, (item + i)->position.x, (item + i)->position.y);}
    }
}