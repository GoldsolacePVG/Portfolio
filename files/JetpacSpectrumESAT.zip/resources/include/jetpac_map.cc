void InitMap(){
    map = (TMap*)malloc(sizeof(TMap) * 4);
    //PLATFORM 1 (GROUND)
    (map + 0)->position.x = 0;
    (map + 0)->position.y = kWindowHeight - 30;
    (map + 0)->sprite = &g_ground_plat;
    (map + 0)->size = {(float)esat::SpriteWidth(g_ground_plat), (float)esat::SpriteHeight(g_ground_plat)};

    //PLATFORM 2 (SMALL)
    (map + 1)->position.x = kWindowWidth/2 - 50;
    (map + 1)->position.y = kWindowHeight/2;
    (map + 1)->sprite = &g_small_plat;
    (map + 1)->size = {(float)esat::SpriteWidth(g_small_plat), (float)esat::SpriteHeight(g_small_plat)};

    //PLATFORM 3 (BIG RIGHT)
    (map + 2)->position.x = kWindowWidth/2 + 250;
    (map + 2)->position.y = kWindowHeight/2 - 200;
    (map + 2)->sprite = &g_big_plat;
    (map + 2)->size = {(float)esat::SpriteWidth(g_big_plat), (float)esat::SpriteHeight(g_big_plat)};

    //PLATFORM 4 (BIG LEFT)
    (map + 3)->position.x = 100;    
    (map + 3)->position.y = kWindowHeight/2 - 100;
    (map + 3)->sprite = &g_big_plat;
    (map + 3)->size = {(float)esat::SpriteWidth(g_big_plat), (float)esat::SpriteHeight(g_big_plat)};
}

void DrawMap(){
    for(int i = 0; i < 4; i++){
        esat::DrawSprite(*(map + i)->sprite, (map + i)->position.x, (map + i)->position.y);
    }
}