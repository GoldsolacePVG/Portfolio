//COLLISIONS
bool Collision(float x1, float y1, float x2, float y2, float w2, float h2){
    return x1>x2 && x1<x2+w2 && y1>y2 && y1<y2+h2;
}

bool BoxCollision(float x1, float y1, float w1, float h1, float x2, float y2, float w2, float h2){

    return Collision(x1,y1,x2,y2,w2,h2) || 
           Collision(x1+w1,y1,x2,y2,w2,h2) || 
           Collision(x1+w1,y1+h1,x2,y2,w2,h2) || 
           Collision(x1,y1+h1,x2,y2,w2,h2);
}

//Player Collisions
bool PlayerToPlatformDownCollision(TPlayer *player){
    bool collision = false;
    for(int i = 0; i < 4 && !collision; i++){
        collision = BoxCollision((*player).position.x, (*player).position.y + 5, (*player).size.x, (*player).size.y,
                                 (map + i)->position.x, (map + i)->position.y - 5, (map + i)->size.x, (map + i)->size.y);
    }
    return !collision;
}

bool PlayerToPlatformUpCollision(TPlayer *player){
    bool collision = false;
    for(int i = 1; i < 4 && !collision; i++){
        collision = BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                                 (map + i)->position.x, (map + i)->position.y + 7, (map + i)->size.x, (map + i)->size.y);
    }
    return !collision;
}

bool PlayerToPlatformRightCollision(TPlayer *player){
    bool collision = false;
    for(int i = 1; i < 4 && !collision; i++){
        collision = BoxCollision((map + i)->position.x, (map + i)->position.y, (map + i)->size.x, (map + i)->size.y,
                                 (*player).position.x + 10, (*player).position.y, (*player).size.x, (*player).size.y);
    }
    return !collision;
}

bool PlayerToPlatformLeftCollision(TPlayer *player){
    bool collision = false;
    for(int i = 1; i < 4 && !collision; i++){
        collision = BoxCollision((map + i)->position.x, (map + i)->position.y, (map + i)->size.x, (map + i)->size.y,
                                 (*player).position.x - 10, (*player).position.y, (*player).size.x, (*player).size.y);
    }
    return !collision;
}

void PlayerToItemCollision(TPlayer *player){
    //Functions
    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                    (item + 1)->position.x, (item + 1)->position.y, (item + 1)->size.x, (item + 1)->size.y) && !(item + 1)->falling && !(item + 1)->has_arrived){
                        (item + 1)->can_move = true;
                        if(!(item + 1)->taken && !(item + 1)->picked){
                            if(g_player_1){
                                (*player).score += (item + 1)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 1)->score;
                            }
                            soloud.play(get_item);
                        }
                        (item + 1)->picked = true;
                        (item + 1)->taken = true;
                    }

    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                    (item + 2)->position.x, (item + 2)->position.y, (item + 2)->size.x, (item + 2)->size.y) && (item + 1)->has_arrived && !(item + 2)->falling && !(item + 2)->has_arrived){
                        (item + 2)->can_move = true;
                        if(!(item + 2)->taken && !(item + 2)->picked){
                            if(g_player_1){
                                (*player).score += (item + 2)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 2)->score;
                            }
                            soloud.play(get_item);
                        }
                        (item + 2)->picked = true;
                        (item + 2)->taken = true;
                    }

    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                     (item + 3)->position.x, (item + 3)->position.y, (item + 3)->size.x, (item + 3)->size.y) && !(item + 3)->falling && (item + 3)->is_alive){
                        (item + 3)->can_move = true;
                        if(!(item + 3)->taken){
                            if(g_player_1){
                                (*player).score += (item + 3)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 3)->score;
                            }
                            soloud.play(get_fuel);
                        }
                        (item + 3)->taken = true;
                    }

    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                    (item + 4)->position.x, (item + 4)->position.y, (item + 4)->size.x, (item + 4)->size.y) && (item + 4)->is_alive){
                        (item + 4)->can_move = true;
                        if (!(item + 4)->taken){
                            if(g_player_1){
                                (*player).score += (item + 4)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 4)->score;
                            }
                        }
                        (item + 4)->is_alive = false;
                        (item + 4)->is_ready = true;
                        g_diamond_t = false;
                        (item + 4)->position.y = 53;
                        soloud.play(get_item);
                    }

    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                     (item + 5)->position.x, (item + 5)->position.y, (item + 5)->size.x, (item + 5)->size.y) && (item + 5)->is_alive){
                        (item + 5)->can_move = true;
                        if (!(item + 5)->taken){
                            if(g_player_1){
                                (*player).score += (item + 5)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 5)->score;
                            }
                        }
                        (item + 5)->is_alive = false;
                        (item + 5)->is_ready = true;
                        g_pearl_t = false;
                        (item + 5)->position.y = 53;
                        soloud.play(get_item);
                    }

    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                     (item + 6)->position.x, (item + 6)->position.y, (item + 6)->size.x, (item + 6)->size.y) && (item + 6)->is_alive){
                        (item + 6)->can_move = true;
                        if(!(item + 6)->taken){
                            if(g_player_1){
                                (*player).score += (item + 6)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 6)->score;
                            }
                        }
                        (item + 6)->is_alive = false;
                        (item + 6)->is_ready = true;
                        g_gold_t = false;
                        (item + 6)->position.y = 53;
                        soloud.play(get_item);
                    }

    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                     (item + 7)->position.x, (item + 7)->position.y, (item + 7)->size.x, (item + 7)->size.y) && (item + 7)->is_alive){
                        (item + 7)->can_move = true;
                        if (!(item + 7)->taken){
                            if(g_player_1){
                                (*player).score += (item + 7)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 7)->score;
                            }
                        }
                        (item + 7)->is_alive = false;
                        (item + 7)->is_ready = true;
                        g_nuclear_t = false;
                        (item + 7)->position.y = 53;
                        soloud.play(get_item);
                    }

    if(BoxCollision((*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y,
                    (item + 8)->position.x, (item + 8)->position.y, (item + 8)->size.x, (item + 8)->size.y) && (item + 8)->is_alive){
                        (item + 8)->can_move = true;
                        if (!(item + 8)->taken){
                            if(g_player_1){
                                (*player).score += (item + 8)->score;
                            }
                            if(g_player_2){
                                (*player).score2 += (item + 8)->score;
                            }
                        }
                        (item + 8)->is_alive = false;
                        (item + 8)->is_ready = true;
                        g_triangle_t = false;
                        (item + 8)->position.y = 53;
                        soloud.play(get_item);
                    }
}

bool PlayerToMobsCollision(TPlayer *player){
    bool collision = false;
    for(int i = 0; i < 6 && !collision; i++){
        collision = BoxCollision((mobs + i)->position.x, (mobs + i)->position.y, (mobs + i)->size.x, (mobs + i)->size.y,
                                 (*player).position.x, (*player).position.y, (*player).size.x, (*player).size.y);
        if(collision && !g_immortal){
            (*player).lives--;
            (*player).position.x = kWindowWidth / 2;
            (*player).position.y = kWindowHeight - 110;
        }
    }
    return collision;
}

void ItemToPlatformCollision(int item_number){
    for(int i = 0; i < 4; i++){
        if(BoxCollision((item + item_number)->position.x + 25, (item + item_number)->position.y + 5, (item + item_number)->size.x - 25, (item + item_number)->size.y,
                        (map + i)->position.x, (map + i)->position.y - 5, (map + i)->size.x, (map + i)->size.y) && !(item + item_number)->taken){
                            (item + item_number)->can_move = false;
                        }
    }
}

void FuelToShipCollision(){
    if(BoxCollision((item + 3)->position.x, (item + 3)->position.y, (item + 3)->size.x, (item + 3)->size.y,
                    (item + 0)->position.x, (item + 0)->position.y, (item + 0)->size.x, (item + 0)->size.y) && (item + 3)->falling){
                        (item + 3)->is_alive = false;
                        (item + 3)->is_ready = true;
                    }
}
//

void EnemyToPlatformColision(int enemy_counter){
    for(int j = 0; j < 4; j++){
        if(BoxCollision((mobs + enemy_counter)->position.x, (mobs + enemy_counter)->position.y, (mobs + enemy_counter)->size.x, (mobs + enemy_counter)->size.y,
                        (map + j)->position.x, (map + j)->position.y, (map + j)->size.x, (map + j)->size.y)){
                            if((mobs + enemy_counter)->index == 1 || (mobs + enemy_counter)->index == 4 || (mobs + enemy_counter)->index == 7){
                                (mobs + enemy_counter)->is_alive = false;
                                (mobs + enemy_counter)->is_ready = true;
                                soloud.play(enemydies);
                            }
                            if((mobs + enemy_counter)->index == 2 || (mobs + enemy_counter)->index == 3 || (mobs + enemy_counter)->index == 6){
                                switch((mobs + enemy_counter)->direction2){
                                    case 0:
                                        (mobs + enemy_counter)->direction2 = 1;
                                    break;
                                    case 1:
                                        (mobs + enemy_counter)->direction2 = 0;
                                    break;
                                }
                                if(BoxCollision((mobs + enemy_counter)->position.x, (mobs + enemy_counter)->position.y, (mobs + enemy_counter)->size.x, (mobs + enemy_counter)->size.y,
                                                (map + j)->position.x + (map + j)->size.x, (map + j)->position.y, (map + j)->size.x, (map + j)->size.y)){
                                                    switch((mobs + enemy_counter)->direction){
                                                        case 1:
                                                            (mobs + enemy_counter)->direction = 3;
                                                        break;
                                                        case 3:
                                                            (mobs + enemy_counter)->direction = 1;
                                                        break;
                                                    }
                                                }
                                if(BoxCollision((mobs + enemy_counter)->position.x, (mobs + enemy_counter)->position.y, (mobs + enemy_counter)->size.x, (mobs + enemy_counter)->size.y,
                                                (map + j)->position.x - (map + j)->size.x, (map + j)->position.y, (map + j)->size.x, (map + j)->size.y)){
                                                    switch((mobs + enemy_counter)->direction){
                                                        case 1:
                                                            (mobs + enemy_counter)->direction = 3;
                                                        break;
                                                        case 3:
                                                            (mobs + enemy_counter)->direction = 1;
                                                        break;
                                                    }
                                                }
                            }
                        }
    }
}

bool OvniCollision(int enemy_number){
    bool collision = false;
    for(int j = 0; j < 4 && !collision; j++){
        collision = BoxCollision((mobs + enemy_number)->position.x, (mobs + enemy_number)->position.y, (mobs + enemy_number)->size.x, (mobs + enemy_number)->size.y,
                                 (map + j)->position.x, (map + j)->position.y, (map + j)->size.x, (map + j)->size.y);
    }
    return collision;
}

void BulletToMobsCollision(int bullet_num){
    bool collision = false;
    for(int j = 0; j < 6 && !collision; j++){
        collision = BoxCollision((bullet + bullet_num)->position.x, (bullet + bullet_num)->position.y, (bullet + bullet_num)->size.x, (bullet + bullet_num)->size.y,
                        (mobs + j)->position.x, (mobs + j)->position.y, (mobs + j)->size.x, (mobs + j)->size.y);
        if(collision && (mobs + j)->is_alive){
                            (mobs + j)->is_alive = false;
                            (mobs + j)->is_ready = true;
                            (bullet + bullet_num)->is_active = false;
                            (bullet + bullet_num)->is_ready = true;
                            soloud.play(enemydies);
                            switch((mobs + j)->index){
                                case 1:
                                    if(g_player_1){
                                        player.score += 25;
                                    }
                                    if(g_player_2){
                                        player.score2 += 25;
                                    }
                                break;
                                case 2:
                                    if(g_player_1){
                                        player.score += 80;
                                    }
                                    if(g_player_2){
                                        player.score2 += 80;
                                    }
                                break;
                                case 3:
                                    if(g_player_1){
                                        player.score += 40;
                                    }
                                    if(g_player_2){
                                        player.score2 += 40;
                                    }
                                break;
                                case 4:
                                    if(g_player_1){
                                        player.score += 55;
                                    }
                                    if(g_player_2){
                                        player.score2 += 55;
                                    }
                                break;
                                case 5:
                                    if(g_player_1){
                                        player.score += 50;
                                    }
                                    if(g_player_2){
                                        player.score2 += 50;
                                    }
                                break;
                                case 6:
                                    if(g_player_1){
                                        player.score += 60;
                                    }
                                    if(g_player_2){
                                        player.score2 += 60;
                                    }
                                break;
                                case 7:
                                    if(g_player_1){
                                        player.score += 25;
                                    }
                                    if(g_player_2){
                                        player.score2 += 25;
                                    }
                                break;
                                case 8:
                                    if(g_player_1){
                                        player.score += 50;
                                    }
                                    if(g_player_2){
                                        player.score2 += 50;
                                    }
                                break;
                            }
        }
    }
}

void ModeChecking(){
    if(g_game_over && !g_player_mode_2){
        if(esat::IsSpecialKeyDown(esat::kSpecialKey_Enter)){
            if(player.score > g_highscore){
                g_highscore = player.score;
            }
            g_game_over = false;
            Init();
            g_ship_complete = false;
            g_ship_full = false;
            g_fuel_counter = 0;
            g_shipfull_alive_1 = false;
            g_shipfull_alive_2 = false;
            g_shipfull_alive_3 = false;
            g_shipfull_alive_4 = false;
            g_shipfull_alive_5 = false;
            g_shipfull_alive_6 = false;
            g_fuel_t = false;
            g_diamond_t = false;
            g_pearl_t = false;
            g_gold_t = false;
            g_nuclear_t = false;
            g_triangle_t = false;
        }
    }else{
        if(g_game_over && g_player_mode_2 && g_player_1){
            if(esat::IsSpecialKeyDown(esat::kSpecialKey_Enter)){
                if(player.score > g_highscore){
                    g_highscore = player.score;
                }
                g_player_1 = false;
                g_player_2 = true;
                g_game_over = false;
                Init();
                g_ship_complete = false;
                g_ship_full = false;
                g_fuel_counter = 0;
                g_shipfull_alive_1 = false;
                g_shipfull_alive_2 = false;
                g_shipfull_alive_3 = false;
                g_shipfull_alive_4 = false;
                g_shipfull_alive_5 = false;
                g_shipfull_alive_6 = false;
                g_fuel_t = false;
                g_diamond_t = false;
                g_pearl_t = false;
                g_gold_t = false;
                g_nuclear_t = false;
                g_triangle_t = false;
            }
        }
        if(g_game_over && g_player_mode_2 && g_player_2){
            if(esat::IsSpecialKeyDown(esat::kSpecialKey_Enter)){
                if(player.score2 > g_highscore){
                    g_highscore = player.score2;
                }
                g_player_2 = false;
                g_player_1 = true;
                g_game_over = false;
                Init();
                g_ship_complete = false;
                g_ship_full = false;
                g_fuel_counter = 0;
                g_shipfull_alive_1 = false;
                g_shipfull_alive_2 = false;
                g_shipfull_alive_3 = false;
                g_shipfull_alive_4 = false;
                g_shipfull_alive_5 = false;
                g_shipfull_alive_6 = false;
                g_fuel_t = false;
                g_diamond_t = false;
                g_pearl_t = false;
                g_gold_t = false;
                g_nuclear_t = false;
                g_triangle_t = false;
            }
        }
    }
}

//SETS
void SetBullet(int bullet_num){
    (bullet + bullet_num)->is_active = true;
    (bullet + bullet_num)->is_ready = false;
    (bullet + bullet_num)->dir = player.dir;
    (bullet + bullet_num)->position.x = player.position.x;
    (bullet + bullet_num)->position.y = player.position.y + (player.size.y / 2);
    (bullet + bullet_num)->color = rand()%3;
}

void SetFuel(){
    g_fuel_t = true;
    (item + 3)->falling = false;
    (item + 3)->is_alive = true;
    (item + 3)->is_ready = false;
    (item + 3)->can_move = true;
    (item + 3)->has_arrived = false;
    (item + 3)->position.x = (item + 3)->aux;
}

void SetDiamond(){
    g_diamond_t = true;
    (item + 4)->is_alive = true;
    (item + 4)->is_ready = false;
    (item + 4)->can_move = true;
    (item + 4)->position.x = (item + 4)->aux;
}

void SetPearl(){
    g_pearl_t = true;
    (item + 5)->is_alive = true;
    (item + 5)->is_ready = false;
    (item + 5)->can_move = true;
    (item + 5)->position.x = (item + 5)->aux;
}

void SetGold(){
    g_gold_t = true;
    (item + 6)->is_alive = true;
    (item + 6)->is_ready = false;
    (item + 6)->can_move = true;
    (item + 6)->position.x = (item + 6)->aux;
}

void SetNuclear(){
    g_nuclear_t = true;
    (item + 7)->is_alive = true;
    (item + 7)->is_ready = false;
    (item + 7)->can_move = true;
    (item + 7)->position.x = (item + 7)->aux;
}

void SetTriangle(){
    g_triangle_t = true;
    (item + 8)->is_alive = true;
    (item + 8)->is_ready = false;
    (item + 8)->can_move = true;
    (item + 8)->position.x = (item + 8)->aux;
}

void SetEnemy(int enemy_number){
    (mobs + enemy_number)->is_alive = true;
    (mobs + enemy_number)->is_ready = false;
    (mobs + enemy_number)->color = rand()%4;
    if(player.level != 4){
        if((mobs + enemy_number)->spawn2 == 0){
            (mobs + enemy_number)->position.x = 0 - 60;
            (mobs + enemy_number)->position.y = (mobs + enemy_number)->aux;
            (mobs + enemy_number)->direction = 1;
            (mobs + enemy_number)->direction2 = rand()%2;
            (mobs + enemy_number)->movements = (rand()%3) + 1;
        }else if((mobs + enemy_number)->spawn2 == 1){
            (mobs + enemy_number)->position.x = kWindowWidth;
            (mobs + enemy_number)->position.y = (mobs + enemy_number)->aux;
            (mobs + enemy_number)->direction = 3;
            (mobs + enemy_number)->direction2 = rand()%2;
            (mobs + enemy_number)->movements = (rand()%3) + 1;
        }
    }else{
        (mobs + enemy_number)->position.x = 0;
        (mobs + enemy_number)->position.y = (mobs + enemy_number)->aux;
        (mobs + enemy_number)->direction2 = rand()%2;
        (mobs + enemy_number)->movements = (rand()%2) + 1;
        (mobs + enemy_number)->is_active = false;
        if((mobs + enemy_number)->spawn2 == 0){
            (mobs + enemy_number)->direction = 3;
        }
        if((mobs + enemy_number)->spawn2 == 1){
            (mobs + enemy_number)->direction = 1;
        }
    }
}

void SetExplosionAnim(float pos_x, float pos_y){
    esat::SpriteHandle *sprite_explosion;
    g_explosion_alive = true;
    if(g_explosion_alive){
        g_explosion_count = 0;
        g_explosion_count++;
        if(g_explosion_count < 5){
            sprite_explosion = (g_explosion_anim_1 + rand()%4);
        }
        if(g_explosion_count >= 5 && g_explosion_count < 10){
            sprite_explosion = (g_explosion_anim_2 + rand()%4);
        }
        if(g_explosion_count >= 10 && g_explosion_count < 15){
            sprite_explosion = (g_explosion_anim_3 + rand()%4);
        }
        if(g_explosion_count == 15){
            g_explosion_alive = false;
        }
    }
    esat::DrawSprite(*sprite_explosion, pos_x, pos_y);
}

//FREES
void FreePointers(){
    free(g_selection_sprite);
    free(g_player);
    free(g_diamond);
    free(g_nuclear);    
    free(g_triangle);
    free(g_fireball_enemy);
    free(g_fluff_enemy);
    free(g_bubble_enemy);
    free(g_plane_enemy);
    free(g_ovni_enemy);
    free(g_cross_enemy);
    free(g_falcon_enemy);
    free(g_glass_enemy);
    free(map);
    free(item);
    free(mobs);
    free(bullet);
    free(g_ship_explosion);
    free(g_explosion_anim_1);
    free(g_explosion_anim_2);    
    free(g_explosion_anim_3);
}