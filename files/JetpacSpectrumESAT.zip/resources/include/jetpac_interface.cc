void InitFont(){
    esat::DrawSetTextFont("resources/font/spectrum.ttf");
    esat::DrawSetTextSize(32.0f);
}

void DrawPresentationMenu(){
    esat::SpriteHandle sprite_men;
    g_menu_counter++;
    g_img_counter++;
    if(g_img_counter < 5){
        sprite_men = g_jet;
        esat::DrawSprite(sprite_men, kWindowWidth/2 - 380, 72);
    }
    if(g_img_counter >= 5 && g_img_counter < 10){
        sprite_men = g_jet_2;
        esat::DrawSprite(sprite_men, kWindowWidth/2 - 380, 72);
    }
    if(g_img_counter == 9){
        g_img_counter = 0;
    }
    esat::DrawText(250, kWindowHeight/2 + 300, "Hecho por:");
    esat::DrawSprite(g_author, kWindowWidth/2 + 50, kWindowHeight/2 + 215);
    if(g_menu_counter == 100){
        g_menu1 = false;
    }
}

void DrawSelectionMenu(){
    esat::SpriteHandle *sprite_select1 = (g_selection_sprite + 1), *sprite_select2 = (g_selection_sprite + 3);
    esat::DrawSprite(*(g_selection_sprite + 0), kWindowWidth/2 - 240, 53);
    if(esat::IsSpecialKeyDown(esat::kSpecialKey_Up) && g_input_count > 1){
        g_input_count--;
    }
    if(esat::IsSpecialKeyDown(esat::kSpecialKey_Down) && g_input_count < 2){
        g_input_count++;
    }
    if(g_input_count == 1){
        g_select_1 = true;
        g_select_2 = false;
    }
    if(g_input_count == 2){
        g_select_1 = false;
        g_select_2 = true;
    }
    if(g_select_1){
        g_select_1_count++;
        if(g_select_1_count < 10){
            sprite_select1 = (g_selection_sprite + 1);
        }
        if(g_select_1_count >= 10 && g_select_1_count < 20){
            sprite_select1 = (g_selection_sprite + 2);
        }
        if(g_select_1_count == 20){g_select_1_count = 0;}
    }
    if(g_select_2){
        g_select_2_count++;
        if(g_select_2_count < 10){
            sprite_select2 = (g_selection_sprite + 3);
        }
        if(g_select_2_count >= 10 && g_select_2_count < 20){
            sprite_select2 = (g_selection_sprite + 4);
        }
        if(g_select_2_count == 20){g_select_2_count = 0;}
    }
    esat::DrawSprite(*sprite_select1, kWindowWidth/2 - 150, kWindowHeight/2 - 100); 
    esat::DrawSprite(*sprite_select2, kWindowWidth/2 - 150, kWindowHeight/2 - 50);
    esat::DrawSprite(*(g_selection_sprite + 5), 120, kWindowHeight - 100);
    if(esat::IsSpecialKeyDown(esat::kSpecialKey_Enter) && g_select_1){
        g_menu2 = false;
        g_player_1 = true;
    }
    if(esat::IsSpecialKeyDown(esat::kSpecialKey_Enter) && g_select_2){
        g_menu2 = false;
        g_player_1 = true;
        g_player_mode_2 = true;
    }
}

void DrawLetters(){
    esat::DrawSprite(g_1up, 150, 0);
    esat::DrawSprite(g_2up, kWindowWidth - 250, 0);
    esat::DrawSprite(g_hi, kWindowWidth/2 - 50, 0);
}

void DrawScores(){
    char *score1;
    score1 = (char*)calloc(6, sizeof(char));
    itoa(player.score, score1, 10);
    esat::DrawText(150, 45, score1);
    esat::DrawSetFillColor(255, 255, 255);
    char *score2;
    score2 = (char*)calloc(6, sizeof(char));
    itoa(player.score2, score2, 10);
    esat::DrawText(kWindowWidth - 250, 45, score2);
    char *hscore;
    hscore = (char*)calloc(6, sizeof(char));
    itoa(g_highscore, hscore, 10);
    esat::DrawText(kWindowWidth / 2 - 50, 45, hscore);
    free(score1);
    free(score2);
    free(hscore);
}

void DrawLives(){
    char *lives;
    lives = (char*)calloc(10, sizeof(char));
    itoa(player.lives, lives, 10);
    esat::DrawText(250, 24, lives);
    esat::DrawSetFillColor(254, 200, 3);
    esat::DrawSprite(g_live, 280, 1);
    free(lives);
}

void DrawGameOver(){
    esat::DrawText(kWindowWidth / 2 - 100, kWindowHeight / 2, "Game Over");
    esat::DrawText(kWindowWidth / 2 - 120, kWindowHeight / 2 + 100, "Press Enter");
    esat::DrawText(kWindowWidth / 2 - 170, kWindowHeight / 2 + 130, "to start again");
    esat::DrawSetFillColor(255, 0, 0);
}

void DrawGameOver2(){
    esat::DrawText(kWindowWidth / 2 - 100, kWindowHeight / 2, "Game Over");
    esat::DrawText(kWindowWidth / 2 - 120, kWindowHeight / 2 + 100, "Press Enter");
    esat::DrawText(kWindowWidth / 2 - 120, kWindowHeight / 2 + 130, "to continue");
    esat::DrawSetFillColor(255, 0, 0);
}

void DrawHUD(){
    DrawLetters();
    DrawScores();
    DrawLives();
}

void HUD(){
    if(g_menu1 && g_menu2){
        DrawPresentationMenu();
    }
    if(!g_menu1 && g_menu2){
        DrawSelectionMenu();
    }
}